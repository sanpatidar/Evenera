<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'evenera');
define('DB_USER', 'root');  // Change this to your database username
define('DB_PASS', '');      // Change this to your database password
