<?php
// Prevent PHP errors from being displayed
error_reporting(0);
ini_set('display_errors', 0);

require_once '../includes/db_connection.php';
require_once '../includes/auth_handler.php';
require_once '../includes/session_handler.php';

// Set JSON content type
header('Content-Type: application/json');

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
  http_response_code(401);
  echo json_encode(['success' => false, 'message' => 'Unauthorized']);
  exit;
}

try {
  $method = $_SERVER['REQUEST_METHOD'];
  $data = json_decode(file_get_contents('php://input'), true);

  // Check if JSON was valid
  if (json_last_error() !== JSON_ERROR_NONE) {
    throw new Exception('Invalid JSON data provided');
  }

  switch ($method) {
    case 'POST':
      if (!isset($data['action'])) {
        throw new Exception('Action is required');
      }

      switch ($data['action']) {
        case 'update_profile':
          // Validate required fields
          if (!isset($data['name']) || empty(trim($data['name']))) {
            throw new Exception('Name is required');
          }

          // Prepare the update data
          $updateData = [
            'name' => trim($data['name']),
            'phone' => isset($data['phone']) ? trim($data['phone']) : null,
            'location' => isset($data['location']) ? trim($data['location']) : null,
            'bio' => isset($data['bio']) ? trim($data['bio']) : null
          ];

          // Update user profile in database using PDO
          $query = "UPDATE users SET 
                        name = :name, 
                        phone = :phone, 
                        location = :location, 
                        bio = :bio,
                        updated_at = CURRENT_TIMESTAMP 
                        WHERE id = :user_id";

          $stmt = $conn->prepare($query);
          $stmt->bindValue(':name', $updateData['name']);
          $stmt->bindValue(':phone', $updateData['phone']);
          $stmt->bindValue(':location', $updateData['location']);
          $stmt->bindValue(':bio', $updateData['bio']);
          $stmt->bindValue(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);

          if ($stmt->execute()) {
            $result = [
              'success' => true,
              'message' => 'Profile updated successfully',
              'data' => $updateData
            ];
          } else {
            throw new Exception('Failed to update profile');
          }
          break;

        case 'update_password':
          if (!isset($data['current_password'], $data['new_password'], $data['confirm_password'])) {
            throw new Exception('All password fields are required');
          }

          if ($data['new_password'] !== $data['confirm_password']) {
            throw new Exception('New passwords do not match');
          }

          // Verify current password
          $stmt = $conn->prepare("SELECT password FROM users WHERE id = :user_id");
          $stmt->bindValue(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
          $stmt->execute();
          $currentHash = $stmt->fetchColumn();

          if (!password_verify($data['current_password'], $currentHash)) {
            throw new Exception('Current password is incorrect');
          }

          // Update password
          $newHash = password_hash($data['new_password'], PASSWORD_DEFAULT);
          $stmt = $conn->prepare("UPDATE users SET password = :password WHERE id = :user_id");
          $stmt->bindValue(':password', $newHash);
          $stmt->bindValue(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);

          if ($stmt->execute()) {
            $result = [
              'success' => true,
              'message' => 'Password updated successfully'
            ];
          } else {
            throw new Exception('Failed to update password');
          }
          break;

        case 'update_notifications':
          $email_notifications = $data['email_notifications'] ?? false;
          $sms_notifications = $data['sms_notifications'] ?? false;
          $push_notifications = $data['push_notifications'] ?? false;

          $stmt = $conn->prepare("UPDATE users SET 
                        email_notifications = :email,
                        sms_notifications = :sms,
                        push_notifications = :push
                        WHERE id = :user_id");

          $stmt->bindValue(':email', $email_notifications, PDO::PARAM_BOOL);
          $stmt->bindValue(':sms', $sms_notifications, PDO::PARAM_BOOL);
          $stmt->bindValue(':push', $push_notifications, PDO::PARAM_BOOL);
          $stmt->bindValue(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);

          if ($stmt->execute()) {
            $result = [
              'success' => true,
              'message' => 'Notification preferences updated successfully'
            ];
          } else {
            throw new Exception('Failed to update notification preferences');
          }
          break;

        default:
          throw new Exception('Invalid action');
      }
      break;

    default:
      throw new Exception('Method not allowed');
  }

  echo json_encode($result);
} catch (Exception $e) {
  http_response_code(400);
  echo json_encode([
    'success' => false,
    'message' => $e->getMessage()
  ]);
}

// Close database connection
if (isset($conn)) {
  mysqli_close($conn);
}
