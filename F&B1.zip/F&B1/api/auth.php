<?php
require_once '../includes/db_connection.php';
require_once '../includes/auth_handler.php';
require_once '../includes/session_handler.php';

header('Content-Type: application/json');

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}

try {
  $authHandler = new AuthHandler($conn);
  $sessionHandler = new CustomSessionHandler($conn);
  $method = $_SERVER['REQUEST_METHOD'];
  $data = json_decode(file_get_contents('php://input'), true);

  switch ($method) {
    case 'POST':
      if (!isset($data['action'])) {
        throw new Exception('Action is required');
      }

      switch ($data['action']) {
        case 'register':
          if (!isset($data['name']) || !isset($data['email']) || !isset($data['password'])) {
            throw new Exception('Missing required fields');
          }
          $result = $authHandler->register($data['name'], $data['email'], $data['password']);
          if ($result['success']) {
            // Set session variables after successful registration
            $_SESSION['user_id'] = $result['data']['id'];
            $_SESSION['user_name'] = $result['data']['name'];
            $_SESSION['user_email'] = $result['data']['email'];
            $_SESSION['auth_token'] = $result['data']['token'];
          }
          break;

        case 'login':
          if (!isset($data['email']) || !isset($data['password'])) {
            throw new Exception('Missing required fields');
          }
          $rememberMe = isset($data['rememberMe']) ? $data['rememberMe'] : false;
          $result = $authHandler->login($data['email'], $data['password'], $rememberMe);
          if ($result['success']) {
            // Set session variables after successful login
            $_SESSION['user_id'] = $result['data']['id'];
            $_SESSION['user_name'] = $result['data']['name'];
            $_SESSION['user_email'] = $result['data']['email'];
            $_SESSION['auth_token'] = $result['data']['token'];
          }
          break;

        case 'verify':
          $token = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
          if (empty($token)) {
            throw new Exception('No token provided');
          }
          $token = str_replace('Bearer ', '', $token);
          $user = $authHandler->validateToken($token);
          if ($user) {
            $result = [
              'success' => true,
              'user' => [
                'id' => $user['id'],
                'name' => $user['name'],
                'email' => $user['email']
              ]
            ];
          } else {
            throw new Exception('Invalid token');
          }
          break;

        case 'forgot-password':
          if (!isset($data['email'])) {
            throw new Exception('Email is required');
          }
          $result = $authHandler->forgotPassword($data['email']);
          break;

        case 'reset-password':
          if (!isset($data['token']) || !isset($data['password'])) {
            throw new Exception('Token and new password are required');
          }
          $result = $authHandler->resetPassword($data['token'], $data['password']);
          break;

        case 'logout':
          // Clear session
          session_unset();
          session_destroy();

          // Clear auth token if provided
          if (isset($data['token'])) {
            $authHandler->logout($data['token']);
          }

          $result = ['success' => true, 'message' => 'Logged out successfully'];
          break;

        default:
          throw new Exception('Invalid action');
      }
      break;

    default:
      throw new Exception('Method not allowed');
  }

  echo json_encode($result);
} catch (Exception $e) {
  http_response_code(500);
  echo json_encode([
    'success' => false,
    'message' => $e->getMessage()
  ]);
}
