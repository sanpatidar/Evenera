<?php
require_once '../includes/db_connection.php';
require_once '../includes/cookie_handler.php';

header('Content-Type: application/json');

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

try {
  $cookieHandler = new CookieHandler($conn);
  $method = $_SERVER['REQUEST_METHOD'];

  switch ($method) {
    case 'GET':
      // Get current cookie settings
      $settings = $cookieHandler->getCookieSettings();
      echo json_encode([
        'success' => true,
        'data' => $settings
      ]);
      break;

    case 'POST':
      // Set cookie preferences
      $data = json_decode(file_get_contents('php://input'), true);

      if (!$data || !isset($data['preference'])) {
        throw new Exception('Invalid preference data');
      }

      $cookieHandler->setCookieConsent(json_encode($data['preference']));
      echo json_encode([
        'success' => true,
        'message' => 'Cookie preferences updated successfully'
      ]);
      break;

    default:
      throw new Exception('Method not allowed');
  }
} catch (Exception $e) {
  http_response_code(500);
  echo json_encode([
    'success' => false,
    'message' => $e->getMessage()
  ]);
}
