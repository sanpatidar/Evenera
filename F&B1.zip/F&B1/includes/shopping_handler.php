<?php
require_once 'db_connection.php';

class ShoppingHandler
{
  private $conn;

  public function __construct($conn)
  {
    $this->conn = $conn;
  }

  public function createShoppingEvent($userId, $eventData)
  {
    try {
      $this->conn->beginTransaction();

      // Insert shopping event
      $stmt = $this->conn->prepare("
                INSERT INTO shopping_events (
                    user_id, title, category, date, budget, location, description
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
            ");

      $stmt->execute([
        $userId,
        $eventData['title'],
        $eventData['category'],
        $eventData['date'],
        $eventData['budget'],
        $eventData['location'],
        $eventData['description']
      ]);

      $eventId = $this->conn->lastInsertId();

      // Insert shopping items
      if (!empty($eventData['shoppingList'])) {
        $stmt = $this->conn->prepare("
                    INSERT INTO shopping_items (
                        event_id, name, category, priority, quantity, budget, 
                        vendor, delivery_date, notes, purchased
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");

        foreach ($eventData['shoppingList'] as $item) {
          $stmt->execute([
            $eventId,
            $item['name'],
            $item['category'],
            $item['priority'],
            $item['quantity'],
            $item['budget'],
            $item['vendor'],
            $item['delivery_date'],
            $item['notes'],
            $item['purchased'] ? 1 : 0
          ]);
        }
      }

      // Insert tasks
      if (!empty($eventData['tasks'])) {
        $stmt = $this->conn->prepare("
                    INSERT INTO shopping_tasks (
                        event_id, title, priority, due_date, assigned_to, 
                        notes, completed
                    ) VALUES (?, ?, ?, ?, ?, ?, ?)
                ");

        foreach ($eventData['tasks'] as $task) {
          $stmt->execute([
            $eventId,
            $task['title'],
            $task['priority'],
            $task['due_date'],
            $task['assigned_to'],
            $task['notes'],
            $task['completed'] ? 1 : 0
          ]);
        }
      }

      $this->conn->commit();
      return [
        'success' => true,
        'id' => $eventId
      ];
    } catch (Exception $e) {
      $this->conn->rollBack();
      error_log('Error creating shopping event: ' . $e->getMessage());
      return [
        'success' => false,
        'message' => 'Failed to create shopping event'
      ];
    }
  }

  public function updateShoppingEvent($eventId, $userId, $eventData)
  {
    try {
      $this->conn->beginTransaction();

      // Update shopping event
      $stmt = $this->conn->prepare("
                UPDATE shopping_events 
                SET title = ?, category = ?, date = ?, budget = ?, 
                    location = ?, description = ?
                WHERE id = ? AND user_id = ?
            ");

      $stmt->execute([
        $eventData['title'],
        $eventData['category'],
        $eventData['date'],
        $eventData['budget'],
        $eventData['location'],
        $eventData['description'],
        $eventId,
        $userId
      ]);

      // Delete existing items and tasks
      $this->conn->prepare("DELETE FROM shopping_items WHERE event_id = ?")->execute([$eventId]);
      $this->conn->prepare("DELETE FROM shopping_tasks WHERE event_id = ?")->execute([$eventId]);

      // Insert updated shopping items
      if (!empty($eventData['shoppingList'])) {
        $stmt = $this->conn->prepare("
                    INSERT INTO shopping_items (
                        event_id, name, category, priority, quantity, budget, 
                        vendor, delivery_date, notes, purchased
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");

        foreach ($eventData['shoppingList'] as $item) {
          $stmt->execute([
            $eventId,
            $item['name'],
            $item['category'],
            $item['priority'],
            $item['quantity'],
            $item['budget'],
            $item['vendor'],
            $item['delivery_date'],
            $item['notes'],
            $item['purchased'] ? 1 : 0
          ]);
        }
      }

      // Insert updated tasks
      if (!empty($eventData['tasks'])) {
        $stmt = $this->conn->prepare("
                    INSERT INTO shopping_tasks (
                        event_id, title, priority, due_date, assigned_to, 
                        notes, completed
                    ) VALUES (?, ?, ?, ?, ?, ?, ?)
                ");

        foreach ($eventData['tasks'] as $task) {
          $stmt->execute([
            $eventId,
            $task['title'],
            $task['priority'],
            $task['due_date'],
            $task['assigned_to'],
            $task['notes'],
            $task['completed'] ? 1 : 0
          ]);
        }
      }

      $this->conn->commit();
      return [
        'success' => true
      ];
    } catch (Exception $e) {
      $this->conn->rollBack();
      error_log('Error updating shopping event: ' . $e->getMessage());
      return [
        'success' => false,
        'message' => 'Failed to update shopping event'
      ];
    }
  }

  public function deleteShoppingEvent($eventId, $userId)
  {
    try {
      $stmt = $this->conn->prepare("DELETE FROM shopping_events WHERE id = ? AND user_id = ?");
      $stmt->execute([$eventId, $userId]);

      return [
        'success' => true
      ];
    } catch (Exception $e) {
      error_log('Error deleting shopping event: ' . $e->getMessage());
      return [
        'success' => false,
        'message' => 'Failed to delete shopping event'
      ];
    }
  }

  public function getShoppingEvent($eventId, $userId)
  {
    try {
      // Get event details
      $stmt = $this->conn->prepare("
                SELECT * FROM shopping_events 
                WHERE id = ? AND user_id = ?
            ");
      $stmt->execute([$eventId, $userId]);
      $event = $stmt->fetch();

      if (!$event) {
        return null;
      }

      // Get shopping items
      $stmt = $this->conn->prepare("
                SELECT * FROM shopping_items 
                WHERE event_id = ?
                ORDER BY category, name
            ");
      $stmt->execute([$eventId]);
      $event['shoppingList'] = $stmt->fetchAll();

      // Get tasks
      $stmt = $this->conn->prepare("
                SELECT * FROM shopping_tasks 
                WHERE event_id = ?
                ORDER BY due_date, priority
            ");
      $stmt->execute([$eventId]);
      $event['tasks'] = $stmt->fetchAll();

      return $event;
    } catch (Exception $e) {
      error_log('Error fetching shopping event: ' . $e->getMessage());
      return null;
    }
  }

  public function getShoppingEvents($userId, $filters = [])
  {
    try {
      $query = "SELECT * FROM shopping_events WHERE user_id = ?";
      $params = [$userId];

      // Apply filters
      if (!empty($filters['search'])) {
        $query .= " AND (title LIKE ? OR description LIKE ?)";
        $searchTerm = "%{$filters['search']}%";
        $params[] = $searchTerm;
        $params[] = $searchTerm;
      }

      if (!empty($filters['category'])) {
        $query .= " AND category = ?";
        $params[] = $filters['category'];
      }

      if (!empty($filters['status'])) {
        $query .= " AND status = ?";
        $params[] = $filters['status'];
      }

      // Apply sorting
      $query .= " ORDER BY ";
      switch ($filters['sort'] ?? 'date-asc') {
        case 'date-desc':
          $query .= "date DESC";
          break;
        case 'category':
          $query .= "category ASC";
          break;
        case 'budget-asc':
          $query .= "budget ASC";
          break;
        case 'budget-desc':
          $query .= "budget DESC";
          break;
        default:
          $query .= "date ASC";
      }

      $stmt = $this->conn->prepare($query);
      $stmt->execute($params);
      return $stmt->fetchAll();
    } catch (Exception $e) {
      error_log('Error fetching shopping events: ' . $e->getMessage());
      return [];
    }
  }

  public function getUpcomingEvents($userId, $limit = 5)
  {
    try {
      $stmt = $this->conn->prepare("
        SELECT * FROM shopping_events 
        WHERE user_id = ? 
        AND date >= CURDATE() 
        ORDER BY date ASC
        LIMIT ?
      ");
      $stmt->execute([$userId, $limit]);
      return $stmt->fetchAll();
    } catch (Exception $e) {
      error_log('Error fetching upcoming shopping events: ' . $e->getMessage());
      return [];
    }
  }
}
