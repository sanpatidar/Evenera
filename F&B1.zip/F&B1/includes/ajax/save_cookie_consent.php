<?php
require_once '../db_connection.php';
require_once '../cookie_handler.php';

header('Content-Type: application/json');

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

try {
    // Get the POST data
    $input = file_get_contents('php://input');
    $preferences = json_decode($input, true);
    
    if (!$preferences || !isset($preferences['analytics']) || !isset($preferences['marketing'])) {
        throw new Exception('Invalid preference data');
    }

    // Initialize cookie handler
    $cookieHandler = new CookieHandler($conn);
    
    // Save the cookie consent
    $cookieHandler->setCookieConsent($preferences);
    
    // Set cookies in browser
    setcookie('cookie_consent', 'accepted', time() + (86400 * 365), '/');
    setcookie('analytics_cookies', $preferences['analytics'] ? 'accepted' : 'rejected', time() + (86400 * 365), '/');
    setcookie('marketing_cookies', $preferences['marketing'] ? 'accepted' : 'rejected', time() + (86400 * 365), '/');
    
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
} 