<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}

class CookieHandler
{
  private $conn;
  private $userId;

  public function __construct($conn)
  {
    $this->conn = $conn;
    $this->userId = $_SESSION['user_id'] ?? null;
  }

  public function checkCookieConsent()
  {
    // Check if user has already made a choice
    if (isset($_COOKIE['cookie_consent'])) {
      return false; // Don't show cookie banner
    }

    // Check if user is logged in and has a preference in database
    if ($this->userId) {
      $stmt = $this->conn->prepare("SELECT cookie_preference FROM users WHERE id = ?");
      $stmt->execute([$this->userId]);
      $result = $stmt->fetch();

      if ($result && $result['cookie_preference']) {
        // Set cookie based on user's preference
        $this->setCookieConsent($result['cookie_preference']);
        return false; // Don't show cookie banner
      }
    }

    return true; // Show cookie banner
  }

  public function setCookieConsent($preferences)
  {
    // Ensure preferences is a JSON string
    $preferencesJson = is_string($preferences) ? $preferences : json_encode($preferences);
    
    // If user is logged in, save preference to database
    if ($this->userId) {
      $stmt = $this->conn->prepare("UPDATE users SET cookie_preference = ? WHERE id = ?");
      $stmt->execute([$preferencesJson, $this->userId]);
    }

    // Log the consent
    $this->logCookieConsent($preferencesJson);
  }

  private function logCookieConsent($preference)
  {
    $stmt = $this->conn->prepare("
            INSERT INTO cookie_consents (
                user_id,
                preference,
                ip_address,
                user_agent,
                created_at
            ) VALUES (?, ?, ?, ?, NOW())
        ");

    $stmt->execute([
      $this->userId,
      $preference,
      $_SERVER['REMOTE_ADDR'],
      $_SERVER['HTTP_USER_AGENT']
    ]);
  }

  public function getCookieSettings()
  {
    if (!$this->userId) {
      return [
        'essential' => true,
        'analytics' => false,
        'marketing' => false
      ];
    }

    $stmt = $this->conn->prepare("SELECT cookie_preference FROM users WHERE id = ?");
    $stmt->execute([$this->userId]);
    $result = $stmt->fetch();

    if ($result && $result['cookie_preference']) {
      return json_decode($result['cookie_preference'], true);
    }

    return [
      'essential' => true,
      'analytics' => false,
      'marketing' => false
    ];
  }
}
