<?php
require_once 'db_connection.php';
require_once 'auth_handler.php';

class CustomSessionHandler
{
  private $conn;
  private $authHandler;

  public function __construct($conn)
  {
    $this->conn = $conn;
    $this->authHandler = new AuthHandler($conn);
  }

  public function checkAuth()
  {
    // Check for token in cookie or session
    $token = $_COOKIE['auth_token'] ?? $_SESSION['auth_token'] ?? null;

    if (!$token) {
      return false;
    }

    // Validate token
    $user = $this->authHandler->validateToken($token);
    if (!$user) {
      $this->clearAuth();
      return false;
    }

    // Set user data in session
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_name'] = $user['name'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['auth_token'] = $token;

    return true;
  }

  public function requireAuth()
  {
    if (!$this->checkAuth()) {
      header('Location: /F&B1/auth/login.php');
      exit;
    }
  }

  public function clearAuth()
  {
    // Clear session
    session_unset();
    session_destroy();

    // Clear cookie
    setcookie('auth_token', '', time() - 3600, '/');

    // Clear database session
    if (isset($_SESSION['auth_token'])) {
      $this->authHandler->logout($_SESSION['auth_token']);
    }
  }
}

// Initialize session if not already started
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}

// Create session handler instance
$sessionHandler = new CustomSessionHandler($conn);

// For protected pages, check authentication
if (
  strpos($_SERVER['REQUEST_URI'], '/dashboard') !== false ||
  strpos($_SERVER['REQUEST_URI'], '/tasks') !== false ||
  strpos($_SERVER['REQUEST_URI'], '/events') !== false
) {
  $sessionHandler->requireAuth();
}
