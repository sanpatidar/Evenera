<?php
require_once 'db_connection.php';

class EventHandler
{
  private $conn;

  public function __construct($conn)
  {
    $this->conn = $conn;
  }

  public function createEvent($userId, $eventData)
  {
    try {
      $this->conn->beginTransaction();

      // Insert event
      $stmt = $this->conn->prepare("
                INSERT INTO events (user_id, title, description, date, category, venue, budget)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");

      $stmt->execute([
        $userId,
        $eventData['title'],
        $eventData['description'],
        $eventData['date'],
        $eventData['category'],
        $eventData['venue'],
        $eventData['budget']
      ]);

      $eventId = $this->conn->lastInsertId();

      // Insert tasks if provided
      if (!empty($eventData['tasks'])) {
        $taskStmt = $this->conn->prepare("
          INSERT INTO event_tasks (event_id, title, category, priority, due_date, assigned_to, notes, status)
          VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')
        ");

        foreach ($eventData['tasks'] as $task) {
          $taskStmt->execute([
            $eventId,
            $task['title'],
            $task['category'],
            $task['priority'],
            $task['due_date'],
            $task['assigned_to'],
            $task['notes']
          ]);
        }
      }

      $this->conn->commit();
      return [
        'success' => true,
        'id' => $eventId
      ];
    } catch (Exception $e) {
      $this->conn->rollBack();
      error_log('Error creating event: ' . $e->getMessage());
      return [
        'success' => false,
        'message' => 'Failed to create event: ' . $e->getMessage()
      ];
    }
  }

  public function updateEvent($eventId, $userId, $eventData)
  {
    try {
      $stmt = $this->conn->prepare("
                UPDATE events 
                SET title = ?, description = ?, date = ?, category = ?, venue = ?, budget = ?
                WHERE id = ? AND user_id = ?
            ");

      $stmt->execute([
        $eventData['title'],
        $eventData['description'],
        $eventData['date'],
        $eventData['category'],
        $eventData['venue'],
        $eventData['budget'],
        $eventId,
        $userId
      ]);

      return [
        'success' => true
      ];
    } catch (Exception $e) {
      error_log('Error updating event: ' . $e->getMessage());
      return [
        'success' => false,
        'message' => 'Failed to update event'
      ];
    }
  }

  public function deleteEvent($eventId, $userId)
  {
    try {
      $stmt = $this->conn->prepare("DELETE FROM events WHERE id = ? AND user_id = ?");
      $stmt->execute([$eventId, $userId]);

      return [
        'success' => true
      ];
    } catch (Exception $e) {
      error_log('Error deleting event: ' . $e->getMessage());
      return [
        'success' => false,
        'message' => 'Failed to delete event'
      ];
    }
  }

  public function getEvent($eventId, $userId)
  {
    try {
      $stmt = $this->conn->prepare("
                SELECT * FROM events 
                WHERE id = ? AND user_id = ?
            ");
      $stmt->execute([$eventId, $userId]);
      return $stmt->fetch();
    } catch (Exception $e) {
      error_log('Error fetching event: ' . $e->getMessage());
      return null;
    }
  }

  public function getEvents($userId, $filters = [])
  {
    try {
      $query = "SELECT * FROM events WHERE user_id = ?";
      $params = [$userId];

      // Apply filters
      if (!empty($filters['search'])) {
        $query .= " AND (title LIKE ? OR description LIKE ?)";
        $searchTerm = "%{$filters['search']}%";
        $params[] = $searchTerm;
        $params[] = $searchTerm;
      }

      if (!empty($filters['category'])) {
        $query .= " AND category = ?";
        $params[] = $filters['category'];
      }

      if (!empty($filters['status'])) {
        $query .= " AND status = ?";
        $params[] = $filters['status'];
      }

      if (!empty($filters['dateStart'])) {
        $query .= " AND date >= ?";
        $params[] = $filters['dateStart'];
      }

      if (!empty($filters['dateEnd'])) {
        $query .= " AND date <= ?";
        $params[] = $filters['dateEnd'];
      }

      // Apply sorting
      $query .= " ORDER BY ";
      switch ($filters['sort'] ?? 'date-asc') {
        case 'date-desc':
          $query .= "date DESC";
          break;
        case 'category':
          $query .= "category ASC";
          break;
        case 'budget-asc':
          $query .= "budget ASC";
          break;
        case 'budget-desc':
          $query .= "budget DESC";
          break;
        default:
          $query .= "date ASC";
      }

      $stmt = $this->conn->prepare($query);
      $stmt->execute($params);
      return $stmt->fetchAll();
    } catch (Exception $e) {
      error_log('Error fetching events: ' . $e->getMessage());
      return [];
    }
  }

  public function getUpcomingEvents($userId, $days = 30)
  {
    try {
      $stmt = $this->conn->prepare("
                SELECT * FROM events 
                WHERE user_id = ? 
                AND date >= CURDATE() 
                AND date <= DATE_ADD(CURDATE(), INTERVAL ? DAY)
                AND status != 'completed'
                ORDER BY date ASC
            ");
      $stmt->execute([$userId, $days]);
      return $stmt->fetchAll();
    } catch (Exception $e) {
      error_log('Error fetching upcoming events: ' . $e->getMessage());
      return [];
    }
  }

  public function updateEventStatus()
  {
    try {
      $stmt = $this->conn->prepare("
                UPDATE events 
                SET status = CASE
                    WHEN date < CURDATE() THEN 'completed'
                    WHEN date = CURDATE() THEN 'ongoing'
                    ELSE 'upcoming'
                END
            ");
      $stmt->execute();
      return true;
    } catch (Exception $e) {
      error_log('Error updating event status: ' . $e->getMessage());
      return false;
    }
  }
}
