<?php
require_once 'db_connection.php';

class AuthHandler
{
  private $conn;

  public function __construct($conn)
  {
    $this->conn = $conn;
  }

  public function getUserById($userId)
  {
    try {
      $stmt = $this->conn->prepare("SELECT id, name, email FROM users WHERE id = ?");
      $stmt->execute([$userId]);
      $user = $stmt->fetch();

      if (!$user) {
        throw new Exception('User not found');
      }

      return $user;
    } catch (Exception $e) {
      error_log('Error in getUserById: ' . $e->getMessage());
      return null;
    }
  }

  public function register($name, $email, $password)
  {
    try {
      // Check if email already exists
      $stmt = $this->conn->prepare("SELECT id FROM users WHERE email = ?");
      $stmt->execute([$email]);
      if ($stmt->fetch()) {
        throw new Exception('Email already registered');
      }

      // Hash password
      $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

      // Insert new user
      $stmt = $this->conn->prepare("
                INSERT INTO users (name, email, password)
                VALUES (?, ?, ?)
            ");
      $stmt->execute([$name, $email, $hashedPassword]);

      $userId = $this->conn->lastInsertId();

      // Generate token
      $token = $this->generateToken();

      // Store session
      $this->storeSession($userId, $token);

      return [
        'success' => true,
        'data' => [
          'id' => $userId,
          'name' => $name,
          'email' => $email,
          'token' => $token
        ]
      ];
    } catch (Exception $e) {
      return [
        'success' => false,
        'message' => $e->getMessage()
      ];
    }
  }

  public function login($email, $password, $rememberMe = false)
  {
    try {
      // Get user
      $stmt = $this->conn->prepare("SELECT id, name, email, password FROM users WHERE email = ?");
      $stmt->execute([$email]);
      $user = $stmt->fetch();

      if (!$user || !password_verify($password, $user['password'])) {
        throw new Exception('Invalid email or password');
      }

      // Generate token
      $token = $this->generateToken();

      // Store session
      $this->storeSession($user['id'], $token, $rememberMe);

      return [
        'success' => true,
        'data' => [
          'id' => $user['id'],
          'name' => $user['name'],
          'email' => $user['email'],
          'token' => $token
        ]
      ];
    } catch (Exception $e) {
      return [
        'success' => false,
        'message' => $e->getMessage()
      ];
    }
  }

  public function forgotPassword($email)
  {
    try {
      // Check if email exists
      $stmt = $this->conn->prepare("SELECT id FROM users WHERE email = ?");
      $stmt->execute([$email]);
      $user = $stmt->fetch();

      if (!$user) {
        throw new Exception('Email not found');
      }

      // Generate reset token
      $token = bin2hex(random_bytes(32));
      $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));

      // Store reset token
      $stmt = $this->conn->prepare("
                UPDATE users 
                SET reset_token = ?, reset_token_expires = ?
                WHERE id = ?
            ");
      $stmt->execute([$token, $expires, $user['id']]);

      // Send reset email (implement your email sending logic here)
      // For now, we'll just return the token
      return [
        'success' => true,
        'message' => 'Password reset instructions sent to your email',
        'token' => $token // Remove this in production
      ];
    } catch (Exception $e) {
      return [
        'success' => false,
        'message' => $e->getMessage()
      ];
    }
  }

  public function resetPassword($token, $newPassword)
  {
    try {
      // Check if token is valid
      $stmt = $this->conn->prepare("
                SELECT id FROM users 
                WHERE reset_token = ? AND reset_token_expires > NOW()
            ");
      $stmt->execute([$token]);
      $user = $stmt->fetch();

      if (!$user) {
        throw new Exception('Invalid or expired reset token');
      }

      // Hash new password
      $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

      // Update password and clear reset token
      $stmt = $this->conn->prepare("
                UPDATE users 
                SET password = ?, reset_token = NULL, reset_token_expires = NULL
                WHERE id = ?
            ");
      $stmt->execute([$hashedPassword, $user['id']]);

      return [
        'success' => true,
        'message' => 'Password reset successfully'
      ];
    } catch (Exception $e) {
      return [
        'success' => false,
        'message' => $e->getMessage()
      ];
    }
  }

  private function generateToken()
  {
    return bin2hex(random_bytes(32));
  }

  private function storeSession($userId, $token, $rememberMe = false)
  {
    $expires = $rememberMe ?
      date('Y-m-d H:i:s', strtotime('+30 days')) :
      date('Y-m-d H:i:s', strtotime('+24 hours'));

    $stmt = $this->conn->prepare("
            INSERT INTO user_sessions (user_id, token, expires_at)
            VALUES (?, ?, ?)
        ");
    $stmt->execute([$userId, $token, $expires]);
  }

  public function validateToken($token)
  {
    $stmt = $this->conn->prepare("
            SELECT u.id, u.name, u.email
            FROM users u
            JOIN user_sessions s ON u.id = s.user_id
            WHERE s.token = ? AND s.expires_at > NOW()
        ");
    $stmt->execute([$token]);
    return $stmt->fetch();
  }

  public function logout($token)
  {
    $stmt = $this->conn->prepare("DELETE FROM user_sessions WHERE token = ?");
    $stmt->execute([$token]);
  }
}
