<?php
require_once 'db_connection.php';

class TaskHandler
{
  private $conn;

  public function __construct($conn)
  {
    $this->conn = $conn;
  }

  public function createTask($userId, $taskData)
  {
    try {
      $stmt = $this->conn->prepare("
                INSERT INTO tasks (user_id, title, description, deadline, priority, category)
                VALUES (?, ?, ?, ?, ?, ?)
            ");

      $stmt->execute([
        $userId,
        $taskData['title'],
        $taskData['description'],
        $taskData['deadline'],
        $taskData['priority'],
        $taskData['category']
      ]);

      return [
        'success' => true,
        'id' => $this->conn->lastInsertId()
      ];
    } catch (Exception $e) {
      error_log('Error creating task: ' . $e->getMessage());
      return [
        'success' => false,
        'message' => 'Failed to create task'
      ];
    }
  }

  public function updateTask($taskId, $userId, $taskData)
  {
    try {
      $stmt = $this->conn->prepare("
                UPDATE tasks 
                SET title = ?, description = ?, deadline = ?, priority = ?, category = ?
                WHERE id = ? AND user_id = ?
            ");

      $stmt->execute([
        $taskData['title'],
        $taskData['description'],
        $taskData['deadline'],
        $taskData['priority'],
        $taskData['category'],
        $taskId,
        $userId
      ]);

      return [
        'success' => true
      ];
    } catch (Exception $e) {
      error_log('Error updating task: ' . $e->getMessage());
      return [
        'success' => false,
        'message' => 'Failed to update task'
      ];
    }
  }

  public function deleteTask($taskId, $userId)
  {
    try {
      $stmt = $this->conn->prepare("DELETE FROM tasks WHERE id = ? AND user_id = ?");
      $stmt->execute([$taskId, $userId]);

      return [
        'success' => true
      ];
    } catch (Exception $e) {
      error_log('Error deleting task: ' . $e->getMessage());
      return [
        'success' => false,
        'message' => 'Failed to delete task'
      ];
    }
  }

  public function getTask($taskId, $userId)
  {
    try {
      $stmt = $this->conn->prepare("
                SELECT * FROM tasks 
                WHERE id = ? AND user_id = ?
            ");
      $stmt->execute([$taskId, $userId]);
      return $stmt->fetch();
    } catch (Exception $e) {
      error_log('Error fetching task: ' . $e->getMessage());
      return null;
    }
  }

  public function getTasks($userId, $filters = [])
  {
    try {
      $query = "SELECT * FROM tasks WHERE user_id = ?";
      $params = [$userId];

      // Apply filters
      if (!empty($filters['status'])) {
        $query .= " AND status = ?";
        $params[] = $filters['status'];
      }

      if (!empty($filters['priority'])) {
        $query .= " AND priority = ?";
        $params[] = $filters['priority'];
      }

      if (!empty($filters['category'])) {
        $query .= " AND category = ?";
        $params[] = $filters['category'];
      }

      // Apply sorting
      $query .= " ORDER BY ";
      switch ($filters['sort'] ?? 'deadline') {
        case 'priority':
          $query .= "FIELD(priority, 'high', 'medium', 'low')";
          break;
        case 'progress':
          $query .= "progress DESC";
          break;
        default:
          $query .= "deadline ASC";
      }

      $stmt = $this->conn->prepare($query);
      $stmt->execute($params);
      return $stmt->fetchAll();
    } catch (Exception $e) {
      error_log('Error fetching tasks: ' . $e->getMessage());
      return [];
    }
  }

  public function updateTaskStatus($taskId, $userId, $status)
  {
    try {
      $stmt = $this->conn->prepare("
                UPDATE tasks 
                SET status = ?, progress = ?
                WHERE id = ? AND user_id = ?
            ");

      $progress = $status === 'completed' ? 100 : 0;
      $stmt->execute([$status, $progress, $taskId, $userId]);

      return [
        'success' => true
      ];
    } catch (Exception $e) {
      error_log('Error updating task status: ' . $e->getMessage());
      return [
        'success' => false,
        'message' => 'Failed to update task status'
      ];
    }
  }

  public function updateTaskProgress($taskId, $userId, $progress)
  {
    try {
      $stmt = $this->conn->prepare("
                UPDATE tasks 
                SET progress = ?, status = ?
                WHERE id = ? AND user_id = ?
            ");

      $status = $progress === 100 ? 'completed' : 'pending';
      $stmt->execute([$progress, $status, $taskId, $userId]);

      return [
        'success' => true
      ];
    } catch (Exception $e) {
      error_log('Error updating task progress: ' . $e->getMessage());
      return [
        'success' => false,
        'message' => 'Failed to update task progress'
      ];
    }
  }

  public function getTaskStats($userId)
  {
    try {
      $stats = [
        'total' => 0,
        'completed' => 0,
        'highPriority' => 0,
        'upcomingDeadlines' => 0
      ];

      // Total tasks
      $stmt = $this->conn->prepare("SELECT COUNT(*) FROM tasks WHERE user_id = ?");
      $stmt->execute([$userId]);
      $stats['total'] = $stmt->fetchColumn();

      // Completed tasks
      $stmt = $this->conn->prepare("SELECT COUNT(*) FROM tasks WHERE user_id = ? AND status = 'completed'");
      $stmt->execute([$userId]);
      $stats['completed'] = $stmt->fetchColumn();

      // High priority tasks
      $stmt = $this->conn->prepare("SELECT COUNT(*) FROM tasks WHERE user_id = ? AND priority = 'high' AND status != 'completed'");
      $stmt->execute([$userId]);
      $stats['highPriority'] = $stmt->fetchColumn();

      // Upcoming deadlines (next 7 days)
      $stmt = $this->conn->prepare("
                SELECT COUNT(*) FROM tasks 
                WHERE user_id = ? 
                AND deadline BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)
                AND status != 'completed'
            ");
      $stmt->execute([$userId]);
      $stats['upcomingDeadlines'] = $stmt->fetchColumn();

      return $stats;
    } catch (Exception $e) {
      error_log('Error fetching task stats: ' . $e->getMessage());
      return null;
    }
  }

  public function getUpcomingReminders($userId, $days = 3)
  {
    try {
      $stmt = $this->conn->prepare("
                SELECT * FROM tasks 
                WHERE user_id = ? 
                AND deadline BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL ? DAY)
                AND status != 'completed'
                ORDER BY deadline ASC
            ");
      $stmt->execute([$userId, $days]);
      return $stmt->fetchAll();
    } catch (Exception $e) {
      error_log('Error fetching upcoming reminders: ' . $e->getMessage());
      return [];
    }
  }
}
