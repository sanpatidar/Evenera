-- Add cookie_preference column to users table if it doesn't exist
ALTER TABLE users ADD COLUMN IF NOT EXISTS cookie_preference JSON;

-- Create cookie_consents table
CREATE TABLE IF NOT EXISTS cookie_consents (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    preference JSON NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4; 