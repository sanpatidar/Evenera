-- Add new columns to users table for profile information
ALTER TABLE users
ADD COLUMN phone VARCHAR(20) NULL,
ADD COLUMN location VARCHAR(255) NULL,
ADD COLUMN bio TEXT NULL,
ADD COLUMN profile_picture VARCHAR(255) NULL,
ADD COLUMN email_notifications BOOLEAN DEFAULT TRUE,
ADD COLUMN sms_notifications BOOLEAN DEFAULT FALSE,
ADD COLUMN push_notifications BOOLEAN DEFAULT TRUE; 