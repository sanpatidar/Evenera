-- Add cookie_preference column to users table
ALTER TABLE users
ADD COLUMN IF NOT EXISTS cookie_preference JSON NULL; 