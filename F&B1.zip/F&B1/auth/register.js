class RegisterManager {
  constructor() {
    this.form = document.getElementById('registerForm');
    this.loadingOverlay = document.getElementById('loading-overlay');
    this.init();
  }

  init() {
    this.setupEventListeners();
  }

  setupEventListeners() {
    this.form.addEventListener('submit', (e) => this.handleRegistration(e));
  }

  async handleRegistration(e) {
    e.preventDefault();

    const name = this.form.name.value;
    const email = this.form.email.value;
    const password = this.form.password.value;
    const confirmPassword = this.form['confirm-password'].value;

    // Validate password match
    if (password !== confirmPassword) {
      this.showError('Passwords do not match');
      return;
    }

    // Validate password strength
    if (!this.validatePassword(password)) {
      this.showError('Password must be at least 6 characters long');
      return;
    }

    try {
      this.showLoading();

      const response = await fetch('/F&B1/api/auth.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          action: 'register',
          name,
          email,
          password
        })
      });

      const data = await response.json();

      if (data.success) {
        // Store authentication token
        sessionStorage.setItem('authToken', data.data.token);

        // Store user data
        localStorage.setItem('userData', JSON.stringify({
          id: data.data.id,
          name: data.data.name,
          email: data.data.email
        }));

        // Redirect to dashboard
        window.location.href = '/F&B1/dashboard.php';
      } else {
        this.showError(data.message || 'Registration failed. Please try again.');
      }
    } catch (error) {
      console.error('Registration error:', error);
      this.showError('An error occurred. Please try again.');
    } finally {
      this.hideLoading();
    }
  }

  validatePassword(password) {
    // Password must be at least 6 characters long
    return password.length >= 6;
  }

  showLoading() {
    if (this.loadingOverlay) {
      this.loadingOverlay.classList.remove('hidden');
    }
  }

  hideLoading() {
    if (this.loadingOverlay) {
      this.loadingOverlay.classList.add('hidden');
    }
  }

  showError(message) {
    // Create error message element if it doesn't exist
    let errorElement = document.getElementById('error-message');
    if (!errorElement) {
      errorElement = document.createElement('div');
      errorElement.id = 'error-message';
      errorElement.className = 'mt-2 text-center text-red-600 text-sm';
      this.form.insertBefore(errorElement, this.form.firstChild);
    }
    errorElement.textContent = message;
  }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  new RegisterManager();
}); 