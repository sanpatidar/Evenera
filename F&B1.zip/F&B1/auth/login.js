class LoginManager {
  constructor() {
    this.form = document.getElementById('loginForm');
    this.loadingOverlay = document.getElementById('loading-overlay');
    this.init();
  }

  init() {
    this.setupEventListeners();
  }

  setupEventListeners() {
    this.form.addEventListener('submit', (e) => this.handleLogin(e));
  }

  async handleLogin(e) {
    e.preventDefault();

    const email = this.form.email.value;
    const password = this.form.password.value;
    const rememberMe = this.form['remember-me'].checked;

    try {
      this.showLoading();

      const response = await fetch('/F&B1/api/auth.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          action: 'login',
          email,
          password,
          rememberMe
        })
      });

      const data = await response.json();

      if (data.success) {
        // Store authentication token
        if (rememberMe) {
          localStorage.setItem('authToken', data.data.token);
        } else {
          sessionStorage.setItem('authToken', data.data.token);
        }

        // Store user data
        localStorage.setItem('userData', JSON.stringify({
          id: data.data.id,
          name: data.data.name,
          email: data.data.email
        }));

        // Redirect to dashboard
        window.location.href = '/F&B1/dashboard.php';
      } else {
        this.showError(data.message || 'Login failed. Please try again.');
      }
    } catch (error) {
      console.error('Login error:', error);
      this.showError('An error occurred. Please try again.');
    } finally {
      this.hideLoading();
    }
  }

  showLoading() {
    if (this.loadingOverlay) {
      this.loadingOverlay.classList.remove('hidden');
    }
  }

  hideLoading() {
    if (this.loadingOverlay) {
      this.loadingOverlay.classList.add('hidden');
    }
  }

  showError(message) {
    // Create error message element if it doesn't exist
    let errorElement = document.getElementById('error-message');
    if (!errorElement) {
      errorElement = document.createElement('div');
      errorElement.id = 'error-message';
      errorElement.className = 'mt-2 text-center text-red-600 text-sm';
      this.form.insertBefore(errorElement, this.form.firstChild);
    }
    errorElement.textContent = message;
  }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  new LoginManager();
}); 