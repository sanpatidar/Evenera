<?php
require_once '../includes/db_connection.php';
require_once '../includes/session_handler.php';

// Initialize session handler
$sessionHandler = new CustomSessionHandler($conn);

// Clear authentication
$sessionHandler->clearAuth();

// Redirect to home page
header('Location: /F&B1/');
exit;
