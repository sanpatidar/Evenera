<?php
require_once '../includes/db_connection.php';
require_once '../includes/auth_handler.php';
require_once '../includes/session_handler.php';

// Initialize handlers
$authHandler = new AuthHandler($conn);
$sessionHandler = new CustomSessionHandler($conn);

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}

// Check if user is already logged in
if (isset($_SESSION['user_id'])) {
  header('Location: /F&B1/dashboard.php');
  exit();
}

// Handle registration form submission
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name = $_POST['name'] ?? '';
  $email = $_POST['email'] ?? '';
  $password = $_POST['password'] ?? '';
  $confirmPassword = $_POST['confirm_password'] ?? '';

  if ($password !== $confirmPassword) {
    $error = 'Passwords do not match';
  } else {
    $result = $authHandler->register($name, $email, $password);

    if ($result['success']) {
      header('Location: /F&B1/auth/login.php?registered=true');
      exit;
    } else {
      $error = $result['message'];
    }
  }
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr" class="h-full">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Register for Evenera">
  <title>Register - Evenera</title>

  <!-- Tailwind CSS -->
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            primary: '#2563EB',
            'primary-hover': '#1D4ED8',
            secondary: '#059669',
            'secondary-hover': '#047857',
            accent: '#F59E0B',
            'accent-hover': '#D97706',
            neutral: {
              50: '#F9FAFB',
              100: '#F3F4F6',
              200: '#E5E7EB',
              300: '#D1D5DB',
              400: '#9CA3AF',
              500: '#6B7280',
              600: '#4B5563',
              700: '#374151',
              800: '#1F2937',
              900: '#111827',
            }
          },
          fontFamily: {
            sans: ['Inter', 'sans-serif'],
            hindi: ['Tiro Devanagari Hindi', 'serif']
          }
        }
      }
    }
  </script>

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Tiro+Devanagari+Hindi&display=swap" rel="stylesheet">

  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body class="min-h-screen bg-neutral-50 text-neutral-900 font-sans">
  <!-- Navigation -->
  <nav class="container mx-auto px-6 py-4 flex justify-between items-center bg-white border-b border-neutral-200">
    <div class="flex items-center space-x-2">
      <img src="/F&B1/assets/images/logo.png" alt="Evenera logo" class="h-10">
      <span class="text-2xl font-bold text-primary">Evenera</span>
    </div>
    <a href="/F&B1/index.php" class="text-neutral-600 hover:text-primary transition-colors">
      <i class="fas fa-home mr-2"></i>Back to Home
    </a>
  </nav>

  <!-- Registration Section -->
  <div class="min-h-[calc(100vh-73px)] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
    <div class="max-w-md w-full space-y-8">
      <div>
        <h2 class="mt-6 text-center text-3xl font-extrabold text-neutral-900">
          Create your account
        </h2>
        <p class="mt-2 text-center text-sm text-neutral-600">
          Or
          <a href="/F&B1/auth/login.php" class="font-medium text-primary hover:text-primary-hover">
            sign in to your account
          </a>
        </p>
      </div>
      <?php if ($error): ?>
        <div class="mb-4 p-4 bg-red-50 border border-red-200 rounded-md">
          <p class="text-sm text-red-600"><?php echo htmlspecialchars($error); ?></p>
        </div>
      <?php endif; ?>
      <div id="errorMessage" class="mb-4 p-4 bg-red-50 border border-red-200 rounded-md hidden">
        <p class="text-sm text-red-600"></p>
      </div>
      <form id="registerForm" class="mt-8 space-y-6" action="/F&B1/auth/register.php" method="POST">
        <div class="rounded-md shadow-sm -space-y-px">
          <div>
            <label for="name" class="sr-only">Full name</label>
            <input id="name" name="name" type="text" required
              class="appearance-none rounded-none relative block w-full px-3 py-2 border border-neutral-300 placeholder-neutral-500 text-neutral-900 rounded-t-md focus:outline-none focus:ring-primary focus:border-primary focus:z-10 sm:text-sm"
              placeholder="Full name">
          </div>
          <div>
            <label for="email" class="sr-only">Email address</label>
            <input id="email" name="email" type="email" required
              class="appearance-none rounded-none relative block w-full px-3 py-2 border border-neutral-300 placeholder-neutral-500 text-neutral-900 focus:outline-none focus:ring-primary focus:border-primary focus:z-10 sm:text-sm"
              placeholder="Email address">
          </div>
          <div>
            <label for="password" class="sr-only">Password</label>
            <input id="password" name="password" type="password" required
              class="appearance-none rounded-none relative block w-full px-3 py-2 border border-neutral-300 placeholder-neutral-500 text-neutral-900 focus:outline-none focus:ring-primary focus:border-primary focus:z-10 sm:text-sm"
              placeholder="Password">
          </div>
          <div>
            <label for="confirm_password" class="sr-only">Confirm password</label>
            <input id="confirm_password" name="confirm_password" type="password" required
              class="appearance-none rounded-none relative block w-full px-3 py-2 border border-neutral-300 placeholder-neutral-500 text-neutral-900 rounded-b-md focus:outline-none focus:ring-primary focus:border-primary focus:z-10 sm:text-sm"
              placeholder="Confirm password">
          </div>
        </div>

        <div>
          <button type="submit"
            class="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-primary hover:bg-primary-hover focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary">
            <span class="absolute left-0 inset-y-0 flex items-center pl-3">
              <i class="fas fa-user-plus text-primary-hover group-hover:text-primary"></i>
            </span>
            Create Account
          </button>
        </div>
      </form>

      <!-- Social Registration -->
      <div class="mt-6">
        <div class="relative">
          <div class="absolute inset-0 flex items-center">
            <div class="w-full border-t border-neutral-300"></div>
          </div>
          <div class="relative flex justify-center text-sm">
            <span class="px-2 bg-neutral-50 text-neutral-500">
              Or continue with
            </span>
          </div>
        </div>

        <div class="mt-6 grid grid-cols-3 gap-3">
          <div>
            <a href="/F&B1/auth/google"
              class="w-full inline-flex justify-center py-2 px-4 border border-neutral-300 rounded-md shadow-sm bg-white text-sm font-medium text-neutral-500 hover:bg-neutral-50">
              <i class="fab fa-google text-red-600"></i>
            </a>
          </div>
          <div>
            <a href="/F&B1/auth/facebook"
              class="w-full inline-flex justify-center py-2 px-4 border border-neutral-300 rounded-md shadow-sm bg-white text-sm font-medium text-neutral-500 hover:bg-neutral-50">
              <i class="fab fa-facebook-f text-blue-600"></i>
            </a>
          </div>
          <div>
            <a href="/F&B1/auth/twitter"
              class="w-full inline-flex justify-center py-2 px-4 border border-neutral-300 rounded-md shadow-sm bg-white text-sm font-medium text-neutral-500 hover:bg-neutral-50">
              <i class="fab fa-twitter text-blue-400"></i>
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Loading Overlay -->
  <div id="loading-overlay" class="fixed inset-0 bg-neutral-900/95 flex items-center justify-center z-50 hidden">
    <div class="text-center">
      <div class="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin-slow mx-auto mb-4">
      </div>
      <p class="text-white text-lg">Loading...</p>
    </div>
  </div>

  <script>
    document.addEventListener('DOMContentLoaded', function() {
      const form = document.getElementById('registerForm');
      const loadingOverlay = document.getElementById('loading-overlay');

      form.addEventListener('submit', async function(e) {
        e.preventDefault();

        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirm_password').value;

        // Password validation
        if (password !== confirmPassword) {
          document.getElementById('errorMessage').querySelector('p').textContent = 'Passwords do not match';
          document.getElementById('errorMessage').classList.remove('hidden');
          return;
        }

        document.getElementById('loading-overlay').style.display = 'flex';

        try {
          const response = await fetch('/F&B1/api/auth.php', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
              action: 'register',
              name: name,
              email: email,
              password: password
            }),
            credentials: 'include' // Important: This ensures cookies are sent with the request
          });

          const data = await response.json();

          if (data.success) {
            // Store auth token if provided
            if (data.data && data.data.token) {
              sessionStorage.setItem('auth_token', data.data.token);
            }

            // Redirect to dashboard
            window.location.href = '/F&B1/dashboard.php';
          } else {
            const errorMessage = document.getElementById('errorMessage');
            errorMessage.querySelector('p').textContent = data.message;
            errorMessage.classList.remove('hidden');
          }
        } catch (error) {
          const errorMessage = document.getElementById('errorMessage');
          errorMessage.querySelector('p').textContent = 'An error occurred. Please try again.';
          errorMessage.classList.remove('hidden');
        } finally {
          document.getElementById('loading-overlay').style.display = 'none';
        }
      });
    });
  </script>
</body>

</html>