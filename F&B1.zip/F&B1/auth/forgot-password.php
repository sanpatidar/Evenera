<?php
require_once '../includes/db_connection.php';
require_once '../includes/session_handler.php';

// Redirect if already logged in
if ($sessionHandler->checkAuth()) {
  header('Location: /F&B1/dashboard.php');
  exit;
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr" class="h-full">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Reset your password - Evenera">
  <title>Forgot Password - Evenera</title>

  <!-- Tailwind CSS -->
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            primary: '#2563EB',
            'primary-hover': '#1D4ED8',
            secondary: '#059669',
            'secondary-hover': '#047857',
            accent: '#F59E0B',
            'accent-hover': '#D97706',
            neutral: {
              50: '#F9FAFB',
              100: '#F3F4F6',
              200: '#E5E7EB',
              300: '#D1D5DB',
              400: '#9CA3AF',
              500: '#6B7280',
              600: '#4B5563',
              700: '#374151',
              800: '#1F2937',
              900: '#111827',
            }
          },
          fontFamily: {
            sans: ['Inter', 'sans-serif'],
            hindi: ['Tiro Devanagari Hindi', 'serif']
          }
        }
      }
    }
  </script>

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Tiro+Devanagari+Hindi&display=swap" rel="stylesheet">

  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body class="min-h-screen bg-neutral-50 text-neutral-900 font-sans">
  <!-- Navigation -->
  <nav class="container mx-auto px-6 py-4 flex justify-between items-center bg-white border-b border-neutral-200">
    <div class="flex items-center space-x-2">
      <img src="/F&B1/assets/images/logo.png" alt="Evenera logo" class="h-10">
      <span class="text-2xl font-bold text-primary">Evenera</span>
    </div>
    <a href="/F&B1/auth/login.php" class="text-neutral-600 hover:text-primary transition-colors">
      <i class="fas fa-arrow-left mr-2"></i>Back to Login
    </a>
  </nav>

  <!-- Forgot Password Section -->
  <div class="min-h-[calc(100vh-73px)] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
    <div class="max-w-md w-full space-y-8">
      <div>
        <h2 class="mt-6 text-center text-3xl font-extrabold text-neutral-900">
          Reset your password
        </h2>
        <p class="mt-2 text-center text-sm text-neutral-600">
          Enter your email address and we'll send you instructions to reset your password.
        </p>
      </div>
      <form id="forgotPasswordForm" class="mt-8 space-y-6" action="#" method="POST">
        <div>
          <label for="email" class="sr-only">Email address</label>
          <input id="email" name="email" type="email" required
            class="appearance-none rounded-md relative block w-full px-3 py-2 border border-neutral-300 placeholder-neutral-500 text-neutral-900 focus:outline-none focus:ring-primary focus:border-primary focus:z-10 sm:text-sm"
            placeholder="Email address">
        </div>

        <div>
          <button type="submit"
            class="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-primary hover:bg-primary-hover focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary">
            <span class="absolute left-0 inset-y-0 flex items-center pl-3">
              <i class="fas fa-paper-plane text-primary group-hover:text-primary-hover"></i>
            </span>
            Send Reset Instructions
          </button>
        </div>
      </form>
    </div>
  </div>

  <!-- Loading Overlay -->
  <div id="loading-overlay" class="fixed inset-0 bg-neutral-900/95 flex items-center justify-center z-50 hidden">
    <div class="text-center">
      <div class="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin-slow mx-auto mb-4">
      </div>
      <p class="text-white text-lg">Loading...</p>
    </div>
  </div>

  <script>
    document.addEventListener('DOMContentLoaded', function() {
      const form = document.getElementById('forgotPasswordForm');
      const loadingOverlay = document.getElementById('loading-overlay');

      form.addEventListener('submit', async function(e) {
        e.preventDefault();

        const email = form.email.value;

        try {
          loadingOverlay.classList.remove('hidden');

          const response = await fetch('/F&B1/api/auth.php', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              action: 'forgot-password',
              email
            })
          });

          const data = await response.json();

          if (data.success) {
            // Show success message
            showMessage(data.message, 'success');
            form.reset();
          } else {
            showMessage(data.message || 'Failed to send reset instructions. Please try again.', 'error');
          }
        } catch (error) {
          console.error('Error:', error);
          showMessage('An error occurred. Please try again.', 'error');
        } finally {
          loadingOverlay.classList.add('hidden');
        }
      });

      function showMessage(message, type) {
        let messageElement = document.getElementById('message');
        if (!messageElement) {
          messageElement = document.createElement('div');
          messageElement.id = 'message';
          messageElement.className = `mt-2 text-center text-sm ${type === 'success' ? 'text-green-600' : 'text-red-600'}`;
          form.insertBefore(messageElement, form.firstChild);
        }
        messageElement.textContent = message;
      }
    });
  </script>
</body>

</html>