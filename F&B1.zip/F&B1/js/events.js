// Initialize GSAP ScrollTrigger
gsap.registerPlugin(ScrollTrigger);

class EventManager {
  constructor() {
    this.currentEvent = null;
    this.eventForm = document.getElementById('event-form');
    this.eventsGrid = document.getElementById('events-grid');
    this.upcomingEventsSection = document.getElementById('upcoming-events');
    this.sidebarUpcomingEvents = document.getElementById('sidebar-upcoming-events');
    this.createEventModal = document.getElementById('create-event-modal');
    this.modalTitle = document.getElementById('modal-title');
    this.setupEventListeners();
  }

  setupEventListeners() {
    // Mobile menu toggle
    const mobileMenuButton = document.getElementById('mobile-menu-button');
    const sidebar = document.getElementById('sidebar');
    mobileMenuButton?.addEventListener('click', () => {
      sidebar.classList.toggle('-translate-x-full');
    });

    // Window resize handler for sidebar
    window.addEventListener('resize', () => {
      if (window.innerWidth >= 768) {
        sidebar.classList.remove('-translate-x-full');
      } else {
        sidebar.classList.add('-translate-x-full');
      }
    });

    // Modal controls
    document.getElementById('create-event-btn')?.addEventListener('click', () => this.showModal());
    document.getElementById('close-modal')?.addEventListener('click', () => this.hideModal());
    document.getElementById('cancel-event')?.addEventListener('click', () => this.hideModal());
    this.createEventModal?.addEventListener('click', (e) => {
      if (e.target === this.createEventModal) {
        this.hideModal();
      }
    });

    // Form submission
    this.eventForm?.addEventListener('submit', (e) => {
      e.preventDefault();
      this.saveEvent();
    });

    // Initialize filters
    this.eventFilter = new EventFilter(this);
  }

  showModal(eventId = null) {
    this.currentEvent = eventId;
    this.modalTitle.textContent = this.currentEvent ? 'Edit Event' : 'Create Event';

    if (this.currentEvent) {
      // Fetch event details
      fetch(`/F&B1/events.php?action=get&id=${eventId}`)
        .then(response => response.json())
        .then(event => {
          document.getElementById('event-title').value = event.title;
          document.getElementById('event-description').value = event.description || '';
          document.getElementById('event-date').value = event.date;
          document.getElementById('event-category').value = event.category;
          document.getElementById('event-venue').value = event.venue || '';
          document.getElementById('event-budget').value = event.budget || '';
        })
        .catch(error => {
          console.error('Error fetching event:', error);
          this.showNotification('Failed to load event details', 'error');
        });
    } else {
      this.eventForm.reset();
    }

    this.createEventModal.classList.remove('hidden');
    gsap.from(this.createEventModal.children[0], {
      opacity: 0,
      y: -50,
      duration: 0.3,
      ease: 'power2.out'
    });
  }

  hideModal() {
    gsap.to(this.createEventModal.children[0], {
      opacity: 0,
      y: -50,
      duration: 0.3,
      ease: 'power2.in',
      onComplete: () => {
        this.createEventModal.classList.add('hidden');
        this.eventForm.reset();
        this.currentEvent = null;
      }
    });
  }

  async saveEvent() {
    const eventData = {
      title: document.getElementById('event-title').value,
      description: document.getElementById('event-description').value,
      date: document.getElementById('event-date').value,
      category: document.getElementById('event-category').value,
      venue: document.getElementById('event-venue').value,
      budget: document.getElementById('event-budget').value
    };

    // Validate required fields
    if (!eventData.title || !eventData.date || !eventData.category) {
      this.showNotification('Please fill in all required fields', 'error');
      return;
    }

    const formData = new FormData();
    formData.append('action', this.currentEvent ? 'update' : 'create');
    if (this.currentEvent) {
      formData.append('id', this.currentEvent);
    }
    Object.entries(eventData).forEach(([key, value]) => {
      formData.append(key, value);
    });

    try {
      const response = await fetch('/F&B1/events.php', {
        method: 'POST',
        body: formData
      });
      const result = await response.json();

      if (result.success) {
        this.showNotification(this.currentEvent ? 'Event updated successfully!' : 'Event created successfully!', 'success');
        this.hideModal();
        window.location.reload(); // Reload to show updated data
      } else {
        throw new Error(result.message || 'Failed to save event');
      }
    } catch (error) {
      console.error('Error saving event:', error);
      this.showNotification(error.message || 'Failed to save event. Please try again.', 'error');
    }
  }

  deleteEvent(eventId) {
    if (confirm('Are you sure you want to delete this event?')) {
      const formData = new FormData();
      formData.append('action', 'delete');
      formData.append('id', eventId);

      fetch('/F&B1/events.php', {
        method: 'POST',
        body: formData
      })
        .then(response => response.json())
        .then(result => {
          if (result.success) {
            this.showNotification('Event deleted successfully!', 'success');
            window.location.reload(); // Reload to show updated data
          } else {
            throw new Error(result.message || 'Failed to delete event');
          }
        })
        .catch(error => {
          console.error('Error deleting event:', error);
          this.showNotification(error.message || 'Failed to delete event. Please try again.', 'error');
        });
    }
  }

  showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `fixed top-4 right-4 px-6 py-3 rounded-lg ${type === 'success' ? 'bg-secondary/20 text-secondary' : 'bg-error-500/20 text-error-500'}`;
    notification.textContent = message;

    document.body.appendChild(notification);

    gsap.from(notification, {
      x: 100,
      opacity: 0,
      duration: 0.3,
      ease: 'power2.out'
    });

    setTimeout(() => {
      gsap.to(notification, {
        x: 100,
        opacity: 0,
        duration: 0.3,
        ease: 'power2.in',
        onComplete: () => notification.remove()
      });
    }, 3000);
  }
}

class EventFilter {
  constructor(eventManager) {
    this.eventManager = eventManager;
    this.filters = {
      search: '',
      category: '',
      status: '',
      dateRange: {
        start: '',
        end: ''
      },
      sort: 'date-asc'
    };
    this.setupFilterListeners();
  }

  setupFilterListeners() {
    document.getElementById('searchInput')?.addEventListener('input', (e) => {
      this.filters.search = e.target.value.toLowerCase();
      this.applyFilters();
    });

    document.getElementById('categoryFilter')?.addEventListener('change', (e) => {
      this.filters.category = e.target.value;
      this.applyFilters();
    });

    document.getElementById('statusFilter')?.addEventListener('change', (e) => {
      this.filters.status = e.target.value;
      this.applyFilters();
    });

    document.getElementById('dateStartFilter')?.addEventListener('change', (e) => {
      this.filters.dateRange.start = e.target.value;
      this.applyFilters();
    });

    document.getElementById('dateEndFilter')?.addEventListener('change', (e) => {
      this.filters.dateRange.end = e.target.value;
      this.applyFilters();
    });

    document.getElementById('sortFilter')?.addEventListener('change', (e) => {
      this.filters.sort = e.target.value;
      this.applyFilters();
    });
  }

  applyFilters() {
    const queryParams = new URLSearchParams();

    if (this.filters.search) queryParams.append('search', this.filters.search);
    if (this.filters.category) queryParams.append('category', this.filters.category);
    if (this.filters.status) queryParams.append('status', this.filters.status);
    if (this.filters.dateRange.start) queryParams.append('dateStart', this.filters.dateRange.start);
    if (this.filters.dateRange.end) queryParams.append('dateEnd', this.filters.dateRange.end);
    if (this.filters.sort) queryParams.append('sort', this.filters.sort);

    window.location.href = `/F&B1/events.php?${queryParams.toString()}`;
  }

  renderFilterTags() {
    const filterTagsContainer = document.getElementById('filterTags');
    if (!filterTagsContainer) return;

    const activeFilters = Object.entries(this.filters)
      .filter(([key, value]) => {
        if (key === 'dateRange') {
          return value.start || value.end;
        }
        if (key === 'sort') {
          return false; // Don't display sort as a tag
        }
        return value;
      });

    if (activeFilters.length === 0) {
      filterTagsContainer.innerHTML = '';
      return;
    }

    filterTagsContainer.innerHTML = `
      <div class="flex flex-wrap gap-2 mb-4">
        ${activeFilters.map(([key, value]) => {
      if (key === 'dateRange') {
        if (!value.start && !value.end) return '';
        return `
              <span class="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm flex items-center">
                <span>Date: ${value.start || 'Any'} - ${value.end || 'Any'}</span>
                <button class="ml-2 hover:text-primary-hover" onclick="eventManager.eventFilter.removeFilter('${key}')">
                  <i class="fas fa-times"></i>
                </button>
              </span>
            `;
      }
      return `
            <span class="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm flex items-center">
              <span>${key.charAt(0).toUpperCase() + key.slice(1)}: ${value}</span>
              <button class="ml-2 hover:text-primary-hover" onclick="eventManager.eventFilter.removeFilter('${key}')">
                <i class="fas fa-times"></i>
              </button>
            </span>
          `;
    }).join('')}
      </div>
    `;
  }

  removeFilter(filterKey) {
    if (filterKey === 'dateRange') {
      this.filters.dateRange = { start: '', end: '' };
    } else {
      this.filters[filterKey] = '';
    }
    this.applyFilters();
  }
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  window.eventManager = new EventManager();

  // GSAP Animations
  gsap.from('header', {
    opacity: 0,
    y: -20,
    duration: 0.6,
    ease: "power2.out"
  });

  gsap.from('.mb-6', {
    opacity: 0,
    y: 30,
    duration: 0.6,
    stagger: 0.1,
    ease: "power2.out",
    scrollTrigger: {
      trigger: '.mb-6',
      start: 'top 80%'
    }
  });

  gsap.from('#upcoming-events > div', {
    opacity: 0,
    y: 30,
    duration: 0.6,
    stagger: 0.1,
    ease: "power2.out",
    scrollTrigger: {
      trigger: '#upcoming-events',
      start: 'top 80%'
    }
  });

  gsap.from('#create-event-btn', {
    opacity: 0,
    scale: 0.8,
    duration: 0.6,
    ease: "back.out(1.7)"
  });
});