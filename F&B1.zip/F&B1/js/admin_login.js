gsap.registerPlugin(ScrollTrigger);

class AdminLoginUIManager {
    constructor() {
        this.loadingOverlay = document.getElementById('loading-overlay');
        this.form = document.querySelector('form');
    }

    initialize() {
        this.setupLoadingOverlay();
        this.initializeAnimations();
    }

    setupLoadingOverlay() {
        if (!this.loadingOverlay || !this.form) return;

        this.form.addEventListener('submit', () => {
            this.loadingOverlay.classList.remove('hidden');
        });
    }

    initializeAnimations() {
        gsap.from('form', {
            opacity: 0,
            y: 30,
            duration: 1,
            ease: 'power2.out'
        });
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const ui = new AdminLoginUIManager();
    ui.initialize();
});