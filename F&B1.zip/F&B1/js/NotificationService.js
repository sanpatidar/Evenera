class NotificationService {
  constructor() {
    this.checkPermission();
    this.reminders = JSON.parse(localStorage.getItem('reminders') || '[]');
    this.startReminderCheck();
  }

  async checkPermission() {
    if ('Notification' in window) {
      if (Notification.permission !== 'granted' && Notification.permission !== 'denied') {
        await Notification.requestPermission();
      }
    }
  }

  startReminderCheck() {
    // Check for reminders every minute
    setInterval(() => this.checkReminders(), 60000);
    // Initial check
    this.checkReminders();
  }

  checkReminders() {
    const now = new Date();
    this.reminders = this.reminders.filter(reminder => {
      if (!reminder.notified && new Date(reminder.reminderTime) <= now) {
        this.showNotification(reminder);
        reminder.notified = true;
        return true;
      }
      return new Date(reminder.reminderTime) > now;
    });
    localStorage.setItem('reminders', JSON.stringify(this.reminders));
  }

  showNotification(reminder) {
    const task = JSON.parse(localStorage.getItem('tasks') || '[]')
      .find(t => t.id === reminder.taskId);

    if (!task) return;

    if ('Notification' in window && Notification.permission === 'granted') {
      const notification = new Notification('Task Reminder', {
        body: `Task "${task.title}" is due ${this.getRelativeTime(task.deadline)}!`,
        icon: '/images/logo.png',
        tag: task.id,
        requireInteraction: true
      });

      notification.onclick = () => {
        window.focus();
        document.location.href = 'tasks.html';
      };
    }

    // Also show in-app notification
    UIManager.showToast(`Task "${task.title}" is due ${this.getRelativeTime(task.deadline)}!`, 'warning');
  }

  addReminder(taskId, reminderTime) {
    this.reminders.push({
      taskId,
      reminderTime: new Date(reminderTime).toISOString(),
      notified: false
    });
    localStorage.setItem('reminders', JSON.stringify(this.reminders));
  }

  getRelativeTime(date) {
    const now = new Date();
    const taskDate = new Date(date);
    const diffTime = Math.abs(taskDate - now);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (taskDate < now) {
      return diffDays === 1 ? 'yesterday' : `${diffDays} days ago`;
    } else {
      return diffDays === 1 ? 'tomorrow' : `in ${diffDays} days`;
    }
  }

  clearReminders() {
    this.reminders = [];
    localStorage.setItem('reminders', JSON.stringify(this.reminders));
  }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  window.notificationService = new NotificationService();
}); 