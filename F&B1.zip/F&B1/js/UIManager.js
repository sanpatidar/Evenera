class UIManager {
  constructor() {
    // Initialize properties
    this.loadingOverlay = null;
    this.toastContainer = null;

    // Setup when DOM is ready
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => this.initialize());
    } else {
      this.initialize();
    }
  }

  initialize() {
    this.loadingOverlay = document.getElementById('loading-overlay');
    this.setupToastContainer();
  }

  setupToastContainer() {
    if (!document.body) return;

    if (!document.getElementById('toast-container')) {
      const container = document.createElement('div');
      container.id = 'toast-container';
      container.className = 'fixed bottom-4 right-4 z-50 flex flex-col gap-2';
      document.body.appendChild(container);
      this.toastContainer = container;
    } else {
      this.toastContainer = document.getElementById('toast-container');
    }
  }

  showLoading() {
    if (this.loadingOverlay) {
      this.loadingOverlay.classList.remove('hidden');
    }
  }

  hideLoading() {
    if (this.loadingOverlay) {
      this.loadingOverlay.classList.add('hidden');
    }
  }

  showToast(message, type = 'info') {
    // Ensure container exists
    if (!this.toastContainer) {
      this.setupToastContainer();
    }
    if (!this.toastContainer) return; // Exit if still no container

    const toast = document.createElement('div');
    const colors = {
      success: 'bg-secondary text-white',
      error: 'bg-error-500 text-white',
      info: 'bg-primary text-white',
      warning: 'bg-accent text-white'
    };

    toast.className = `${colors[type]} px-4 py-2 rounded-sm shadow-lg flex items-center justify-between min-w-[300px] transform transition-all duration-300 translate-x-full`;
    toast.innerHTML = `
      <span>${message}</span>
      <button class="ml-4 hover:text-neutral-200">
        <i class="fas fa-times"></i>
      </button>
    `;

    this.toastContainer.appendChild(toast);

    // Trigger animation
    setTimeout(() => {
      toast.classList.remove('translate-x-full');
    }, 10);

    // Add click handler to close button
    toast.querySelector('button').addEventListener('click', () => {
      toast.classList.add('translate-x-full');
      setTimeout(() => {
        if (this.toastContainer.contains(toast)) {
          this.toastContainer.removeChild(toast);
        }
      }, 300);
    });

    // Auto remove after 5 seconds
    setTimeout(() => {
      if (this.toastContainer && this.toastContainer.contains(toast)) {
        toast.classList.add('translate-x-full');
        setTimeout(() => {
          if (this.toastContainer && this.toastContainer.contains(toast)) {
            this.toastContainer.removeChild(toast);
          }
        }, 300);
      }
    }, 5000);
  }

  showLoadingSpinner(show = true) {
    if (!this.loadingOverlay) {
      this.loadingOverlay = document.getElementById('loading-overlay');
      if (!this.loadingOverlay && document.body) {
        this.loadingOverlay = document.createElement('div');
        this.loadingOverlay.id = 'loading-overlay';
        this.loadingOverlay.className = 'fixed inset-0 bg-neutral-900/95 flex items-center justify-center z-50 hidden';
        this.loadingOverlay.innerHTML = `
          <div class="text-center">
            <div class="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin-slow mx-auto mb-4">
            </div>
            <p class="text-white text-lg">Loading...</p>
          </div>
        `;
        document.body.appendChild(this.loadingOverlay);
      }
    }

    if (this.loadingOverlay) {
      this.loadingOverlay.classList.toggle('hidden', !show);
    }
  }

  updateProgressBar(elementId, progress) {
    const progressBar = document.getElementById(elementId);
    if (progressBar) {
      progressBar.style.width = `${progress}%`;
    }

    const progressText = document.getElementById(`${elementId}-text`);
    if (progressText) {
      progressText.textContent = `${progress}%`;
    }
  }
} 