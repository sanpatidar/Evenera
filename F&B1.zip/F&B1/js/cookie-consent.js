document.addEventListener('DOMContentLoaded', function () {
  const cookieConsent = document.getElementById('cookie-consent');
  const cookieSettingsModal = document.getElementById('cookie-settings-modal');
  const acceptCookiesBtn = document.getElementById('accept-cookies');
  const cookieSettingsBtn = document.getElementById('cookie-settings');
  const closeSettingsBtn = document.getElementById('close-settings');
  const saveSettingsBtn = document.getElementById('save-settings');
  const analyticsCookies = document.getElementById('analytics-cookies');
  const marketingCookies = document.getElementById('marketing-cookies');

  // Check if cookie consent has been given
  function hasConsentCookie() {
    return document.cookie.split(';').some(item => item.trim().startsWith('cookie_consent='));
  }

  // Set cookie with expiry
  function setCookie(name, value, days) {
    const date = new Date();
    date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
    const expires = "; expires=" + date.toUTCString();
    document.cookie = name + "=" + value + expires + "; path=/";
  }

  // Save cookie preferences to server
  async function saveCookiePreferencesToServer(preferences) {
    try {
      const response = await fetch('/F&B1/includes/ajax/save_cookie_consent.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(preferences)
      });
      
      const data = await response.json();
      if (!data.success) {
        console.error('Failed to save cookie preferences:', data.message);
      }
    } catch (error) {
      console.error('Error saving cookie preferences:', error);
    }
  }

  // Save cookie preferences
  function saveCookiePreferences(analytics = false, marketing = false) {
    // Set cookies in browser
    setCookie('cookie_consent', 'accepted', 365);
    setCookie('analytics_cookies', analytics ? 'accepted' : 'rejected', 365);
    setCookie('marketing_cookies', marketing ? 'accepted' : 'rejected', 365);

    // Save preferences to server
    const preferences = {
      analytics: analytics,
      marketing: marketing
    };
    saveCookiePreferencesToServer(preferences);

    // Hide cookie banner
    if (cookieConsent) {
      cookieConsent.style.display = 'none';
    }
  }

  // Event Listeners
  if (acceptCookiesBtn) {
    acceptCookiesBtn.addEventListener('click', function () {
      saveCookiePreferences(true, true);
    });
  }

  if (cookieSettingsBtn) {
    cookieSettingsBtn.addEventListener('click', function () {
      if (cookieSettingsModal) {
        cookieSettingsModal.classList.remove('hidden');
      }
    });
  }

  if (closeSettingsBtn) {
    closeSettingsBtn.addEventListener('click', function () {
      if (cookieSettingsModal) {
        cookieSettingsModal.classList.add('hidden');
      }
    });
  }

  if (saveSettingsBtn) {
    saveSettingsBtn.addEventListener('click', function () {
      const analyticsAccepted = analyticsCookies ? analyticsCookies.checked : false;
      const marketingAccepted = marketingCookies ? marketingCookies.checked : false;

      saveCookiePreferences(analyticsAccepted, marketingAccepted);

      if (cookieSettingsModal) {
        cookieSettingsModal.classList.add('hidden');
      }
    });
  }

  // Close modal when clicking outside
  window.addEventListener('click', function (event) {
    if (event.target === cookieSettingsModal) {
      cookieSettingsModal.classList.add('hidden');
    }
  });

  // Show cookie banner if consent hasn't been given
  if (!hasConsentCookie() && cookieConsent) {
    cookieConsent.style.display = 'block';
  }
}); 