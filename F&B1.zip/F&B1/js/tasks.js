class TaskManager {
  constructor() {
    this.currentTask = null;
    this.taskForm = document.getElementById('task-form');
    this.taskList = document.querySelector('.task-list');
    this.taskModal = document.getElementById('task-modal');
    this.modalTitle = document.getElementById('modal-title');
    this.loadingOverlay = document.getElementById('loading-overlay');
    this.remindersList = document.getElementById('reminders-list');
    this.setupEventListeners();
  }

  setupEventListeners() {
    // Mobile menu toggle
    const mobileMenuButton = document.getElementById('mobile-menu-button');
    const sidebar = document.getElementById('sidebar');
    mobileMenuButton?.addEventListener('click', () => {
      sidebar.classList.toggle('-translate-x-full');
    });

    // Task creation
    document.getElementById('create-task-btn')?.addEventListener('click', () => this.showTaskModal());
    this.taskForm?.addEventListener('submit', (e) => {
      e.preventDefault();
      this.saveTask();
    });

    // Modal controls
    document.getElementById('modal-close')?.addEventListener('click', () => this.hideTaskModal());
    document.getElementById('cancel-task-btn')?.addEventListener('click', () => this.hideTaskModal());

    // Task filters and sorting
    document.getElementById('task-filter')?.addEventListener('change', (e) => this.filterTasks(e.target.value));
    document.getElementById('task-sort')?.addEventListener('change', (e) => this.sortTasks(e.target.value));
  }

  showTaskModal(taskId = null) {
    this.currentTask = taskId;
    this.modalTitle.textContent = this.currentTask ? 'Edit Task' : 'Create Task';

    if (this.currentTask) {
      // Fetch task details
      fetch(`/F&B1/tasks.php?action=get&id=${taskId}`)
        .then(response => response.json())
        .then(task => {
          document.getElementById('task-title').value = task.title;
          document.getElementById('task-description').value = task.description || '';
          document.getElementById('task-deadline').value = task.deadline;
          document.getElementById('task-priority').value = task.priority;
          document.getElementById('task-category').value = task.category || '';
        })
        .catch(error => {
          console.error('Error fetching task:', error);
          this.showToast('Failed to load task details', 'error');
        });
    } else {
      this.taskForm.reset();
    }

    this.taskModal.classList.remove('hidden');
  }

  hideTaskModal() {
    this.taskModal.classList.add('hidden');
    this.currentTask = null;
    this.taskForm.reset();
  }

  async saveTask() {
    try {
      this.showLoading();

      const taskData = {
        title: document.getElementById('task-title').value,
        description: document.getElementById('task-description').value,
        deadline: document.getElementById('task-deadline').value,
        priority: document.getElementById('task-priority').value,
        category: document.getElementById('task-category').value
      };

      const formData = new FormData();
      formData.append('action', this.currentTask ? 'update' : 'create');
      if (this.currentTask) {
        formData.append('id', this.currentTask);
      }
      Object.entries(taskData).forEach(([key, value]) => {
        formData.append(key, value);
      });

      const response = await fetch('/F&B1/tasks.php', {
        method: 'POST',
        body: formData
      });
      const result = await response.json();

      if (result.success) {
        this.showToast(this.currentTask ? 'Task updated successfully!' : 'Task created successfully!', 'success');
        this.hideTaskModal();
        window.location.reload(); // Reload to show updated data
      } else {
        throw new Error(result.message || 'Failed to save task');
      }
    } catch (error) {
      console.error('Error saving task:', error);
      this.showToast(error.message || 'Failed to save task. Please try again.', 'error');
    } finally {
      this.hideLoading();
    }
  }

  async deleteTask(taskId) {
    if (confirm('Are you sure you want to delete this task?')) {
      try {
        this.showLoading();
        const formData = new FormData();
        formData.append('action', 'delete');
        formData.append('id', taskId);

        const response = await fetch('/F&B1/tasks.php', {
          method: 'POST',
          body: formData
        });
        const result = await response.json();

        if (result.success) {
          this.showToast('Task deleted successfully!', 'success');
          window.location.reload(); // Reload to show updated data
        } else {
          throw new Error(result.message || 'Failed to delete task');
        }
      } catch (error) {
        console.error('Error deleting task:', error);
        this.showToast(error.message || 'Failed to delete task. Please try again.', 'error');
      } finally {
        this.hideLoading();
      }
    }
  }

  async toggleTaskComplete(taskId) {
    try {
      this.showLoading();
      const formData = new FormData();
      formData.append('action', 'updateStatus');
      formData.append('id', taskId);
      formData.append('status', 'completed');

      const response = await fetch('/F&B1/tasks.php', {
        method: 'POST',
        body: formData
      });
      const result = await response.json();

      if (result.success) {
        window.location.reload(); // Reload to show updated data
      } else {
        throw new Error(result.message || 'Failed to update task status');
      }
    } catch (error) {
      console.error('Error updating task status:', error);
      this.showToast(error.message || 'Failed to update task status. Please try again.', 'error');
    } finally {
      this.hideLoading();
    }
  }

  async updateProgress(taskId, progress) {
    try {
      this.showLoading();
      const formData = new FormData();
      formData.append('action', 'updateProgress');
      formData.append('id', taskId);
      formData.append('progress', progress);

      const response = await fetch('/F&B1/tasks.php', {
        method: 'POST',
        body: formData
      });
      const result = await response.json();

      if (result.success) {
        window.location.reload(); // Reload to show updated data
      } else {
        throw new Error(result.message || 'Failed to update task progress');
      }
    } catch (error) {
      console.error('Error updating task progress:', error);
      this.showToast(error.message || 'Failed to update task progress. Please try again.', 'error');
    } finally {
      this.hideLoading();
    }
  }

  filterTasks(criteria) {
    const queryParams = new URLSearchParams();

    switch (criteria) {
      case 'incomplete':
        queryParams.append('status', 'pending');
        break;
      case 'completed':
        queryParams.append('status', 'completed');
        break;
      case 'high-priority':
        queryParams.append('priority', 'high');
        break;
    }

    window.location.href = `/F&B1/tasks.php?${queryParams.toString()}`;
  }

  sortTasks(criteria) {
    const queryParams = new URLSearchParams();
    queryParams.append('sort', criteria);
    window.location.href = `/F&B1/tasks.php?${queryParams.toString()}`;
  }

  showLoading() {
    this.loadingOverlay.classList.remove('hidden');
  }

  hideLoading() {
    this.loadingOverlay.classList.add('hidden');
  }

  showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `fixed bottom-4 right-4 px-4 py-2 rounded-sm text-white ${type === 'success' ? 'bg-secondary' :
      type === 'error' ? 'bg-error-500' :
        'bg-primary'
      }`;
    toast.textContent = message;
    document.body.appendChild(toast);

    setTimeout(() => {
      toast.remove();
    }, 3000);
  }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  window.taskManager = new TaskManager();
});