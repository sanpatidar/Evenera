gsap.registerPlugin(ScrollTrigger);

class ContactUIManager {
  constructor() {
    // Cache DOM elements
    this.mobileMenu = document.getElementById('mobile-menu');
    this.mobileMenuButton = document.getElementById('mobile-menu-button');
    this.loadingOverlay = document.getElementById('loading-overlay');
    this.notification = document.getElementById('notification');
    this.notificationMessage = document.getElementById('notification-message');
    this.contactForm = document.getElementById('contact-form-element');
    this.adminIdInput = document.getElementById('admin_id');
    this.contactAdminButtons = document.querySelectorAll('.contact-admin-btn');
    this.adminCards = document.querySelectorAll('.admin-card');
  }

  initialize() {
    this.setupMobileMenu();
    this.setupLoadingOverlay();
    this.setupNotifications();
    this.setupContactForm();
    this.initializeAnimations();
    this.setupSmoothScroll();
    this.setupAdminCards();
  }

  setupMobileMenu() {
    if (!this.mobileMenu || !this.mobileMenuButton) return;

    this.mobileMenuButton.addEventListener('click', () => {
      const isExpanded = this.mobileMenuButton.getAttribute('aria-expanded') === 'true';
      this.mobileMenuButton.setAttribute('aria-expanded', !isExpanded);
      this.mobileMenu.classList.toggle('hidden');
    });

    document.addEventListener('click', (e) => {
      if (!this.mobileMenu.contains(e.target) &&
        !this.mobileMenuButton.contains(e.target) &&
        !this.mobileMenu.classList.contains('hidden')) {
        this.mobileMenu.classList.add('hidden');
        this.mobileMenuButton.setAttribute('aria-expanded', 'false');
      }
    });
  }

  setupLoadingOverlay() {
    if (!this.loadingOverlay) return;

    document.querySelectorAll('a').forEach(link => {
      if (link.href && !link.href.startsWith('#') && !link.hasAttribute('data-no-loading')) {
        link.addEventListener('click', () => {
          this.loadingOverlay.classList.remove('hidden');
        });
      }
    });
  }

  setupNotifications() {
    if (!this.notification || !this.notificationMessage) return;

    document.addEventListener('showNotification', (e) => {
      this.showNotification(e.detail.message, e.detail.type, e.detail.duration);
    });
  }

  showNotification(message, type = 'success', duration = 3000) {
    if (!this.notification || !this.notificationMessage) return;

    const icons = {
      success: 'fa-check-circle text-green-600',
      error: 'fa-exclamation-circle text-red-600',
      warning: 'fa-exclamation-triangle text-yellow-600',
      info: 'fa-info-circle text-blue-600'
    };

    this.notificationMessage.textContent = message;
    document.getElementById('notification-icon').className = `fas ${icons[type] || icons.info}`;
    this.notification.classList.remove('hidden');

    setTimeout(() => {
      this.notification.classList.add('hidden');
    }, duration);
  }

  setupContactForm() {
    if (!this.contactForm || !this.adminIdInput) return;

    this.contactAdminButtons.forEach(button => {
      button.addEventListener('click', () => {
        const adminId = button.getAttribute('data-admin-id');
        const adminName = button.getAttribute('data-admin-name');
        this.adminIdInput.value = adminId;

        // Scroll to form
        document.getElementById('contact-form').scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });

        // Show notification
        this.showNotification(`Sending message to ${adminName}`, 'info', 3000);
      });
    });
  }

  initializeAnimations() {
    // Hero section animation
    gsap.from('.contact-hero h1', {
      opacity: 0,
      y: 30,
      duration: 1,
      scrollTrigger: {
        trigger: '.contact-hero',
        start: 'top center'
      }
    });

    // Admin cards animation
    gsap.from('.admin-card', {
      opacity: 0,
      y: 30,
      duration: 1,
      stagger: {
        each: 0.2,
        from: "start"
      },
      ease: "power2.out",
      scrollTrigger: {
        trigger: '#admins',
        start: 'top center+=100',
        toggleActions: 'play none none none'
      }
    });

    // Contact form animation
    gsap.from('#contact-form', {
      opacity: 0,
      y: 30,
      duration: 1,
      scrollTrigger: {
        trigger: '#contact-form',
        start: 'top center+=100'
      }
    });
  }

  setupSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', (e) => {
        e.preventDefault();
        const targetId = anchor.getAttribute('href');
        const targetElement = document.querySelector(targetId);

        if (targetElement) {
          targetElement.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
          });

          if (this.mobileMenu && !this.mobileMenu.classList.contains('hidden')) {
            this.mobileMenu.classList.add('hidden');
            this.mobileMenuButton.setAttribute('aria-expanded', 'false');
          }
        }
      });
    });
  }

  setupAdminCards() {
    this.adminCards.forEach(card => {
      const tl = gsap.timeline({ paused: true });

      tl.to(card, {
        y: -8,
        scale: 1.02,
        duration: 0.3,
        ease: 'power2.out',
        boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1)'
      });

      card.addEventListener('mouseenter', () => tl.play());
      card.addEventListener('mouseleave', () => tl.reverse());
    });
  }
}

document.addEventListener('DOMContentLoaded', () => {
  const ui = new ContactUIManager();
  ui.initialize();

  // Show welcome notification
  setTimeout(() => {
    const event = new CustomEvent('showNotification', {
      detail: {
        message: 'Welcome to our Contact page! Reach out to our team! 📧',
        type: 'success',
        duration: 4000
      }
    });
    document.dispatchEvent(event);
  }, 1000);
});