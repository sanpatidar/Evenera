// Initialize GSAP ScrollTrigger
gsap.registerPlugin(ScrollTrigger);

class ShoppingManager {
  constructor() {
    this.shoppingEventForm = document.getElementById('shopping-event-form');
    this.shoppingEventsGrid = document.getElementById('shopping-events-grid');
    this.sidebarUpcomingEvents = document.getElementById('sidebar-upcoming-events');
    this.shoppingEventModal = document.getElementById('shopping-event-modal');
    this.setupEventListeners();
    this.displayUpcomingEvents();
    this.initializeAnimations();
  }

  setupEventListeners() {
    // Mobile menu toggle
    const mobileMenuButton = document.getElementById('mobile-menu-button');
    const sidebar = document.getElementById('sidebar');
    mobileMenuButton?.addEventListener('click', () => {
      sidebar.classList.toggle('-translate-x-full');
    });

    // Window resize handler for sidebar
    window.addEventListener('resize', () => {
      if (window.innerWidth >= 768) {
        sidebar.classList.remove('-translate-x-full');
      } else {
        sidebar.classList.add('-translate-x-full');
      }
    });

    // Shopping Event Modal controls
    document.getElementById('create-shopping-event-btn')?.addEventListener('click', () => this.showModal());
    document.getElementById('close-modal')?.addEventListener('click', () => this.hideModal());
    document.getElementById('cancel-event')?.addEventListener('click', () => this.hideModal());
    this.shoppingEventModal?.addEventListener('click', (e) => {
      if (e.target === this.shoppingEventModal) {
        this.hideModal();
      }
    });

    // Form submission
    this.shoppingEventForm?.addEventListener('submit', (e) => {
      e.preventDefault();
      this.saveEvent();
    });

    // Add item and task buttons
    document.getElementById('add-item-modal-btn')?.addEventListener('click', () => this.addItem('modal-shopping-list'));
    document.getElementById('add-task-modal-btn')?.addEventListener('click', () => this.addTask('modal-task-list'));

    // Edit and Delete buttons
    document.querySelectorAll('.edit-event-btn').forEach(button => {
      button.addEventListener('click', () => {
        const eventId = button.getAttribute('data-event-id');
        this.showModal(eventId);
      });
    });

    document.querySelectorAll('.delete-event-btn').forEach(button => {
      button.addEventListener('click', () => {
        const eventId = button.getAttribute('data-event-id');
        this.deleteEvent(eventId);
      });
    });

    // Initialize filters
    this.eventFilter = new EventFilter(this);
  }

  initializeAnimations() {
    // Animate header
    gsap.from('header', {
      opacity: 0,
      y: -20,
      duration: 0.6,
      ease: "power2.out"
    });

    // Animate filters section
    gsap.from('.mb-6', {
      opacity: 0,
      y: 30,
      duration: 0.6,
      stagger: 0.1,
      ease: "power2.out",
      scrollTrigger: {
        trigger: '.mb-6',
        start: 'top 80%'
      }
    });

    // Animate create button
    gsap.from('#create-shopping-event-btn', {
      opacity: 0,
      scale: 0.8,
      duration: 0.6,
      ease: "back.out(1.7)"
    });

    // Animate shopping event cards
    gsap.from('.shopping-event-card', {
      y: 50,
      opacity: 0,
      duration: 0.5,
      stagger: 0.1,
      ease: 'power2.out',
      scrollTrigger: {
        trigger: '#shopping-events-grid',
        start: 'top 80%'
      }
    });

    // Animate background elements
    const backgroundElements = document.querySelectorAll('[data-speed]');
    backgroundElements.forEach(element => {
      const speed = parseFloat(element.dataset.speed);
      gsap.to(element, {
        y: 'random(-20, 20)',
        x: 'random(-20, 20)',
        duration: 'random(5, 10)',
        repeat: -1,
        yoyo: true,
        ease: 'sine.inOut'
      });
    });
  }

  showModal(eventId = null) {
    if (eventId) {
      // Fetch event data from server
      fetch(`/F&B1/shopping.php?action=get&id=${eventId}`)
        .then(response => response.json())
        .then(event => {
          this.currentEvent = event;
          this.populateModal(event);
        })
        .catch(error => {
          console.error('Error fetching event:', error);
          this.showNotification('Failed to load event data', 'error');
        });
    } else {
      this.currentEvent = null;
      this.populateModal(null);
    }

    this.shoppingEventModal.classList.remove('hidden');
    gsap.from(this.shoppingEventModal.children[0], {
      opacity: 0,
      y: -50,
      duration: 0.3,
      ease: 'power2.out'
    });
  }

  populateModal(event) {
    document.getElementById('modal-title').textContent = event ? 'Edit Shopping Event' : 'Create Shopping Event';
    document.getElementById('event-id').value = event?.id || '';
    document.getElementById('event-title').value = event?.title || '';
    document.getElementById('event-category').value = event?.category || '';
    document.getElementById('event-date').value = event?.date || '';
    document.getElementById('event-budget').value = event?.budget || '';
    document.getElementById('event-location').value = event?.location || '';
    document.getElementById('event-description').value = event?.description || '';

    const shoppingList = document.getElementById('modal-shopping-list');
    const taskList = document.getElementById('modal-task-list');
    shoppingList.innerHTML = '';
    taskList.innerHTML = '';

    if (event) {
      event.shoppingList.forEach(item => this.addItem('modal-shopping-list', item));
      event.tasks.forEach(task => this.addTask('modal-task-list', task));
    }
  }

  hideModal() {
    gsap.to(this.shoppingEventModal.children[0], {
      opacity: 0,
      y: -50,
      duration: 0.3,
      ease: 'power2.in',
      onComplete: () => {
        this.shoppingEventModal.classList.add('hidden');
        this.shoppingEventForm.reset();
        document.getElementById('modal-shopping-list').innerHTML = '';
        document.getElementById('modal-task-list').innerHTML = '';
        this.currentEvent = null;
      }
    });
  }

  addItem(listId, item = null) {
    const shoppingList = document.getElementById(listId);
    const itemTemplate = document.getElementById('item-template').content.cloneNode(true);
    const itemRow = itemTemplate.querySelector('.item-row');

    if (item) {
      itemRow.querySelector('.item-purchased').checked = item.purchased || false;
      itemRow.querySelector('.item-name').value = item.name;
      itemRow.querySelector('.item-category').value = item.category;
      itemRow.querySelector('.item-priority').value = item.priority || 'medium';
      itemRow.querySelector('.item-quantity').value = item.quantity;
      itemRow.querySelector('.item-budget').value = item.budget;
      itemRow.querySelector('.item-vendor').value = item.vendor || '';
      itemRow.querySelector('.item-delivery-date').value = item.delivery_date || '';
      itemRow.querySelector('.item-notes').value = item.notes || '';
    } else {
      itemRow.querySelector('.item-quantity').value = 1;
      itemRow.querySelector('.item-budget').value = 0;
    }

    // Toggle Details
    itemRow.querySelector('.toggle-details').addEventListener('click', () => {
      const itemDetails = itemRow.querySelector('.item-details');
      itemDetails.classList.toggle('hidden');
      const icon = itemRow.querySelector('.toggle-details i');
      icon.classList.toggle('fa-chevron-down');
      icon.classList.toggle('fa-chevron-up');
    });

    // Delete Item
    itemRow.querySelector('.delete-item').addEventListener('click', () => {
      itemRow.remove();
    });

    shoppingList.appendChild(itemTemplate);
  }

  addTask(listId, task = null) {
    const taskList = document.getElementById(listId);
    const taskTemplate = document.getElementById('task-template').content.cloneNode(true);
    const taskItem = taskTemplate.querySelector('.task-item');

    if (task) {
      taskItem.querySelector('.task-checkbox').checked = task.completed || false;
      taskItem.querySelector('.task-title').value = task.title;
      taskItem.querySelector('.task-priority').value = task.priority || 'medium';
      taskItem.querySelector('.task-due-date').value = task.due_date || '';
      taskItem.querySelector('.task-assigned').value = task.assigned_to || '';
      taskItem.querySelector('.task-notes').value = task.notes || '';
    }

    // Toggle Details
    taskItem.querySelector('.toggle-details').addEventListener('click', () => {
      const taskDetails = taskItem.querySelector('.task-details');
      taskDetails.classList.toggle('hidden');
      const icon = taskItem.querySelector('.toggle-details i');
      icon.classList.toggle('fa-chevron-down');
      icon.classList.toggle('fa-chevron-up');
    });

    // Delete Task
    taskItem.querySelector('.delete-task').addEventListener('click', () => {
      taskItem.remove();
    });

    taskList.appendChild(taskTemplate);
  }

  saveEvent() {
    const eventId = document.getElementById('event-id').value;
    const eventData = {
      title: document.getElementById('event-title').value,
      category: document.getElementById('event-category').value,
      date: document.getElementById('event-date').value,
      budget: parseInt(document.getElementById('event-budget').value),
      location: document.getElementById('event-location').value,
      description: document.getElementById('event-description').value,
      shoppingList: Array.from(document.getElementById('modal-shopping-list').querySelectorAll('.item-row')).map(row => ({
        purchased: row.querySelector('.item-purchased').checked,
        name: row.querySelector('.item-name').value,
        category: row.querySelector('.item-category').value,
        priority: row.querySelector('.item-priority').value,
        quantity: parseInt(row.querySelector('.item-quantity').value),
        budget: parseInt(row.querySelector('.item-budget').value),
        vendor: row.querySelector('.item-vendor').value,
        delivery_date: row.querySelector('.item-delivery-date').value,
        notes: row.querySelector('.item-notes').value
      })),
      tasks: Array.from(document.getElementById('modal-task-list').querySelectorAll('.task-item')).map(task => ({
        completed: task.querySelector('.task-checkbox').checked,
        title: task.querySelector('.task-title').value,
        priority: task.querySelector('.task-priority').value,
        due_date: task.querySelector('.task-due-date').value,
        assigned_to: task.querySelector('.task-assigned').value,
        notes: task.querySelector('.task-notes').value
      }))
    };

    console.log('Form Data:', eventData); // Debug log

    // Validate required fields
    if (!eventData.title || !eventData.category || !eventData.date || !eventData.budget) {
      this.showNotification('Please fill all required fields.', 'error');
      console.log('Validation failed:', { // Debug log
        title: !eventData.title,
        category: !eventData.category,
        date: !eventData.date,
        budget: !eventData.budget
      });
      return;
    }

    const formData = new FormData();
    formData.append('action', eventId ? 'update' : 'create');
    if (eventId) formData.append('id', eventId);
    formData.append('title', eventData.title);
    formData.append('category', eventData.category);
    formData.append('date', eventData.date);
    formData.append('budget', eventData.budget);
    formData.append('location', eventData.location);
    formData.append('description', eventData.description);
    formData.append('shoppingList', JSON.stringify(eventData.shoppingList));
    formData.append('tasks', JSON.stringify(eventData.tasks));

    console.log('Sending request to server...'); // Debug log

    fetch('/F&B1/shopping.php', {
      method: 'POST',
      body: formData
    })
      .then(response => {
        console.log('Response status:', response.status); // Debug log
        return response.json();
      })
      .then(result => {
        console.log('Server response:', result); // Debug log
        if (result.success) {
          this.showNotification(eventId ? 'Shopping event updated successfully!' : 'Shopping event created successfully!', 'success');
          this.hideModal();
          window.location.reload(); // Refresh to show updated data
        } else {
          this.showNotification(result.message || 'Failed to save shopping event', 'error');
        }
      })
      .catch(error => {
        console.error('Error saving shopping event:', error);
        this.showNotification('Failed to save shopping event. Please try again.', 'error');
      });
  }

  deleteEvent(eventId) {
    if (!confirm('Are you sure you want to delete this shopping event?')) return;

    const formData = new FormData();
    formData.append('action', 'delete');
    formData.append('id', eventId);

    fetch('/F&B1/shopping.php', {
      method: 'POST',
      body: formData
    })
      .then(response => response.json())
      .then(result => {
        if (result.success) {
          this.showNotification('Shopping event deleted successfully!', 'success');
          window.location.reload(); // Refresh to show updated data
        } else {
          this.showNotification(result.message || 'Failed to delete shopping event', 'error');
        }
      })
      .catch(error => {
        console.error('Error deleting shopping event:', error);
        this.showNotification('Failed to delete shopping event. Please try again.', 'error');
      });
  }

  displayUpcomingEvents() {
    fetch('/F&B1/shopping.php?action=upcoming')
      .then(response => response.json())
      .then(events => {
        this.sidebarUpcomingEvents.innerHTML = events.length > 0 ? events.map(event => {
          const eventDate = new Date(event.date);
          const now = new Date();
          const diffDays = Math.ceil((eventDate - now) / (1000 * 60 * 60 * 24));
          return `
            <div class="bg-neutral-50 p-3 rounded-sm">
              <p class="font-medium text-neutral-800">${event.title}</p>
              <div class="flex items-center justify-between mt-1">
                <span class="text-sm text-neutral-500"><i class="fas fa-calendar-alt mr-1"></i>${eventDate.toLocaleDateString('en-IN')}</span>
                <span class="text-xs px-2 py-1 bg-primary/10 text-primary rounded-full">${diffDays} day${diffDays !== 1 ? 's' : ''} left</span>
              </div>
            </div>
          `;
        }).join('') : '<p class="text-neutral-500">No upcoming events.</p>';
      })
      .catch(error => {
        console.error('Error fetching upcoming events:', error);
        this.sidebarUpcomingEvents.innerHTML = '<p class="text-neutral-500">Error loading upcoming events.</p>';
      });
  }

  showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `fixed top-4 right-4 px-6 py-3 rounded-lg ${type === 'success' ? 'bg-secondary/20 text-secondary' : 'bg-error-500/20 text-error-500'}`;
    notification.textContent = message;

    document.body.appendChild(notification);

    gsap.from(notification, {
      x: 100,
      opacity: 0,
      duration: 0.3,
      ease: 'power2.out'
    });

    setTimeout(() => {
      gsap.to(notification, {
        x: 100,
        opacity: 0,
        duration: 0.3,
        ease: 'power2.in',
        onComplete: () => notification.remove()
      });
    }, 3000);
  }
}

class EventFilter {
  constructor(shoppingManager) {
    this.shoppingManager = shoppingManager;
    this.filters = {
      search: '',
      category: '',
      status: ''
    };
    this.setupFilterListeners();
  }

  setupFilterListeners() {
    document.getElementById('search-events')?.addEventListener('input', (e) => {
      this.filters.search = e.target.value.toLowerCase();
      this.applyFilters();
    });

    document.getElementById('category-filter')?.addEventListener('change', (e) => {
      this.filters.category = e.target.value;
      this.applyFilters();
    });

    document.getElementById('status-filter')?.addEventListener('change', (e) => {
      this.filters.status = e.target.value;
      this.applyFilters();
    });
  }

  applyFilters() {
    const queryParams = new URLSearchParams();
    if (this.filters.search) queryParams.append('search', this.filters.search);
    if (this.filters.category) queryParams.append('category', this.filters.category);
    if (this.filters.status) queryParams.append('status', this.filters.status);

    window.location.href = `/F&B1/shopping.php?${queryParams.toString()}`;
  }
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  window.shoppingManager = new ShoppingManager();
});