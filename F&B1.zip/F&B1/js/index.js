// Initialize GSAP ScrollTrigger
gsap.registerPlugin(ScrollTrigger);

class UIManager {
  constructor() {
    // Cache DOM elements
    this.mobileMenu = document.getElementById('mobile-menu');
    this.mobileMenuButton = document.getElementById('mobile-menu-button');
    this.loadingOverlay = document.getElementById('loading-overlay');
    this.notification = document.getElementById('notification');
    this.notificationText = document.getElementById('notification-text');

    // Initialize GSAP
    gsap.registerPlugin(ScrollTrigger);
  }

  initialize() {
    this.setupMobileMenu();
    this.setupLoadingOverlay();
    this.setupNotifications();
    this.initializeAnimations();
    this.setupSmoothScroll();
    this.setupFeatureCards();
    this.setupParallax();
  }

  setupMobileMenu() {
    if (!this.mobileMenu || !this.mobileMenuButton) return;

    this.mobileMenuButton.addEventListener('click', () => {
      const isExpanded = this.mobileMenuButton.getAttribute('aria-expanded') === 'true';
      this.mobileMenuButton.setAttribute('aria-expanded', !isExpanded);
      this.mobileMenu.classList.toggle('hidden');
    });

    // Close menu when clicking outside
    document.addEventListener('click', (e) => {
      if (!this.mobileMenu.contains(e.target) &&
        !this.mobileMenuButton.contains(e.target) &&
        !this.mobileMenu.classList.contains('hidden')) {
        this.mobileMenu.classList.add('hidden');
        this.mobileMenuButton.setAttribute('aria-expanded', 'false');
      }
    });
  }

  setupLoadingOverlay() {
    if (!this.loadingOverlay) return;

    document.querySelectorAll('a').forEach(link => {
      if (link.href && !link.href.startsWith('#') && !link.hasAttribute('data-no-loading')) {
        link.addEventListener('click', () => {
          this.loadingOverlay.classList.remove('hidden');
        });
      }
    });
  }

  setupNotifications() {
    if (!this.notification || !this.notificationText) return;

    document.addEventListener('showNotification', (e) => {
      this.showNotification(e.detail.message, e.detail.type, e.detail.duration);
    });
  }

  showNotification(message, type = 'success', duration = 3000) {
    if (!this.notification || !this.notificationText) return;

    const colors = {
      success: 'bg-green-500',
      error: 'bg-red-500',
      warning: 'bg-yellow-500',
      info: 'bg-blue-500'
    };

    this.notification.className = `fixed bottom-4 right-4 p-4 rounded-lg shadow-lg ${colors[type] || colors.info} text-white`;
    this.notificationText.textContent = message;
    this.notification.classList.remove('hidden');

    setTimeout(() => {
      this.notification.classList.add('hidden');
    }, duration);
  }

  initializeAnimations() {
    // Hero section animations
    gsap.from('.hero-content h1', {
      opacity: 0,
      y: 30,
      duration: 1,
      scrollTrigger: {
        trigger: '.hero-content',
        start: 'top center'
      }
    });

    // Feature cards animation
    gsap.from('.feature-card', {
      opacity: 0,
      y: 30,
      duration: 1,
      stagger: {
        each: 0.2,
        from: "start"
      },
      ease: "power2.out",
      scrollTrigger: {
        trigger: '#features',
        start: 'top center+=100',
        toggleActions: 'play none none none'
      }
    });

    // Testimonial cards animation with improved visibility
    gsap.from('.testimonial', {
      opacity: 0,
      y: 30,
      duration: 1,
      stagger: {
        each: 0.2,
        from: "start"
      },
      ease: "power2.out",
      scrollTrigger: {
        trigger: '#testimonials',
        start: 'top center+=100',
        toggleActions: 'play none none none'
      }
    });

    // Setup testimonial hover effects
    this.setupTestimonialCards();
  }

  setupTestimonialCards() {
    const testimonials = document.querySelectorAll('.testimonial');
    testimonials.forEach(card => {
      // Create a GSAP timeline for each testimonial
      const tl = gsap.timeline({ paused: true });

      tl.to(card, {
        y: -5,
        scale: 1.01,
        duration: 0.3,
        ease: 'power2.out',
        boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)'
      });

      // Add hover listeners
      card.addEventListener('mouseenter', () => tl.play());
      card.addEventListener('mouseleave', () => tl.reverse());
    });
  }

  setupSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', (e) => {
        e.preventDefault();
        const targetId = anchor.getAttribute('href');
        const targetElement = document.querySelector(targetId);

        if (targetElement) {
          targetElement.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
          });

          // Close mobile menu if open
          if (this.mobileMenu && !this.mobileMenu.classList.contains('hidden')) {
            this.mobileMenu.classList.add('hidden');
            this.mobileMenuButton.setAttribute('aria-expanded', 'false');
          }
        }
      });
    });
  }

  setupFeatureCards() {
    const cards = document.querySelectorAll('.feature-card');
    cards.forEach(card => {
      // Create a GSAP timeline for each card
      const tl = gsap.timeline({ paused: true });

      tl.to(card, {
        y: -8,
        scale: 1.02,
        duration: 0.3,
        ease: 'power2.out',
        boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1)'
      });

      // Add hover listeners
      card.addEventListener('mouseenter', () => tl.play());
      card.addEventListener('mouseleave', () => tl.reverse());
    });
  }

  setupParallax() {
    // Remove the hero parallax since we don't have a background image setup
    const parallaxElements = document.querySelectorAll('.parallax');
    if (parallaxElements.length > 0) {
      parallaxElements.forEach(element => {
        gsap.to(element, {
          y: -50,
          ease: 'none',
          scrollTrigger: {
            trigger: element,
            start: 'top bottom',
            end: 'bottom top',
            scrub: true
          }
        });
      });
    }
  }
}

// Initialize UI when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  const ui = new UIManager();
  ui.initialize();

  // Show welcome notification after a short delay
  setTimeout(() => {
    const event = new CustomEvent('showNotification', {
      detail: {
        message: 'Welcome to F&B Events! 🎉',
        type: 'success',
        duration: 4000
      }
    });
    document.dispatchEvent(event);
  }, 1000);
}); 