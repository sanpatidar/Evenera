class UserManager {
  constructor() {
    this.checkAuthentication();
    this.loadUserData();
  }

  checkAuthentication() {
    const token = localStorage.getItem('authToken') || sessionStorage.getItem('authToken');
    if (!token) {
      window.location.href = '/F&B1/auth/login.html';
      return;
    }
  }

  async loadUserData() {
    try {
      // First try to get from localStorage
      const userData = JSON.parse(localStorage.getItem('userData'));
      const token = localStorage.getItem('authToken') || sessionStorage.getItem('authToken');

      if (!userData && token) {
        // If we have a token but no user data, fetch it from the API
        const response = await fetch('/F&B1/api/auth.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({ action: 'verify' })
        });

        if (response.ok) {
          const data = await response.json();
          if (data.success && data.user) {
            // Store the user data
            localStorage.setItem('userData', JSON.stringify(data.user));
            this.updateUIWithUserData(data.user);
            return;
          }
        }
        // If we couldn't get user data, redirect to login
        window.location.href = '/F&B1/auth/login.html';
        return;
      }

      if (userData) {
        this.updateUIWithUserData(userData);
      } else {
        window.location.href = '/F&B1/auth/login.html';
      }
    } catch (error) {
      console.error('Error loading user data:', error);
      window.location.href = '/F&B1/auth/login.html';
    }
  }

  updateUIWithUserData(userData) {
    // Update profile button
    const profileButton = document.querySelector('.group button span');
    if (profileButton) {
      profileButton.textContent = userData.name;
    }

    // Update dropdown menu
    const dropdownMenu = document.querySelector('.group .hidden');
    if (dropdownMenu) {
      const nameElement = dropdownMenu.querySelector('p.font-medium');
      const emailElement = dropdownMenu.querySelector('p.text-sm');

      if (nameElement) {
        nameElement.textContent = userData.name;
      }
      if (emailElement) {
        emailElement.textContent = userData.email;
      }
    }

    // Update welcome message if it exists
    const welcomeMessage = document.getElementById('welcome-message');
    if (welcomeMessage) {
      welcomeMessage.textContent = `Welcome back, ${userData.name}!`;
    }
  }

  async handleLogout() {
    try {
      const token = localStorage.getItem('authToken') || sessionStorage.getItem('authToken');
      const response = await fetch('/F&B1/api/auth.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ action: 'logout' })
      });

      if (response.ok) {
        // Clear all stored data
        localStorage.removeItem('userData');
        localStorage.removeItem('authToken');
        sessionStorage.removeItem('authToken');
        localStorage.removeItem('events');
        localStorage.removeItem('guests');
        localStorage.removeItem('budget');
        localStorage.removeItem('tasks');

        window.location.href = '/F&B1/index.html';
      } else {
        throw new Error('Logout failed');
      }
    } catch (error) {
      console.error('Logout failed:', error);
      // Show error toast if available
      if (typeof UIManager !== 'undefined') {
        UIManager.showToast('Logout failed. Please try again.', 'error');
      }
    }
  }
} 