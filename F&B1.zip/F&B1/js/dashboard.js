// Initialize GSAP ScrollTrigger
gsap.registerPlugin(ScrollTrigger);

class StateManager {
  constructor() {
    this.state = {
      events: JSON.parse(localStorage.getItem('events') || '[]'),
      guests: JSON.parse(localStorage.getItem('guests') || '[]'),
      tasks: JSON.parse(localStorage.getItem('tasks') || '[]')
    };
  }

  updateState() {
    this.state = {
      events: JSON.parse(localStorage.getItem('events') || '[]'),
      guests: JSON.parse(localStorage.getItem('guests') || '[]'),
      tasks: JSON.parse(localStorage.getItem('tasks') || '[]')
    };
    return this.state;
  }
}

class UIManager {
  constructor() {
    this.setupMobileMenu();
    this.setupProfileDropdown();
    this.initializeAnimations();
    this.initializeDigitalClock();
    this.initializeCalendar();
    this.displayUpcomingFestivals();
  }

  setupMobileMenu() {
    const mobileMenuButton = document.getElementById('mobile-menu-button');
    const sidebar = document.getElementById('sidebar');

    mobileMenuButton?.addEventListener('click', () => {
      sidebar.classList.toggle('-translate-x-full');
    });
  }

  setupProfileDropdown() {
    const profileButton = document.querySelector('.group button');
    const dropdown = document.querySelector('.group .hidden');

    profileButton?.addEventListener('click', () => {
      dropdown.classList.toggle('hidden');
    });

    document.addEventListener('click', (e) => {
      if (profileButton && dropdown && !profileButton.contains(e.target) && !dropdown.contains(e.target)) {
        dropdown.classList.add('hidden');
      }
    });
  }

  initializeAnimations() {
    // Animate white background elements
    const whiteBgElements = document.querySelectorAll('.bg-white');
    if (whiteBgElements.length > 0) {
      gsap.from(whiteBgElements, {
        opacity: 0,
        y: 20,
        duration: 0.5,
        stagger: 0.1,
        scrollTrigger: {
          trigger: 'main',
          start: 'top 80%'
        }
      });
    }

    // Animate grid elements
    const gridElements = document.querySelectorAll('.grid > div');
    if (gridElements.length > 0) {
      gsap.from(gridElements, {
        y: 50,
        opacity: 0,
        duration: 0.5,
        stagger: 0.1,
        ease: 'power2.out',
        scrollTrigger: {
          trigger: '.grid',
          start: 'top center'
        }
      });
    }

    // Animate background elements
    const backgroundElements = document.querySelectorAll('[data-speed]');
    backgroundElements.forEach(element => {
      const speed = parseFloat(element.dataset.speed);
      gsap.to(element, {
        y: 'random(-20, 20)',
        x: 'random(-20, 20)',
        duration: 'random(5, 10)',
        repeat: -1,
        yoyo: true,
        ease: 'sine.inOut'
      });
    });

    // Animate festival cards if they exist
    const festivalCards = document.querySelectorAll('#upcoming-festivals > div');
    if (festivalCards.length > 0) {
      gsap.from(festivalCards, {
        opacity: 0,
        scale: 0.95,
        duration: 0.5,
        stagger: 0.1,
        ease: 'power2.out',
        scrollTrigger: {
          trigger: '#upcoming-festivals',
          start: 'top 80%'
        }
      });
    }
  }

  initializeDigitalClock() {
    const updateClock = () => {
      const now = new Date();
      const timeElement = document.getElementById('digital-clock-time');
      const dateElement = document.getElementById('digital-clock-date');

      if (timeElement && dateElement) {
        timeElement.textContent = now.toLocaleTimeString('en-IN', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit'
        });
        dateElement.textContent = now.toLocaleDateString('en-IN', {
          weekday: 'long',
          year: 'numeric',
          month: 'long',
          day: 'numeric'
        });
      }
    };

    updateClock();
    setInterval(updateClock, 1000);
  }

  initializeCalendar() {
    let currentMonth = new Date().getMonth();
    let currentYear = new Date().getFullYear();

    // Indian festivals for 2025
    const festivals = [
      { date: '2025-01-14', name: 'Makar Sankranti' },
      { date: '2025-02-12', name: 'Vasant Panchami' },
      { date: '2025-03-14', name: 'Holi' },
      { date: '2025-04-14', name: 'Baisakhi' },
      { date: '2025-08-09', name: 'Raksha Bandhan' },
      { date: '2025-08-16', name: 'Janmashtami' },
      { date: '2025-09-05', name: 'Ganesh Chaturthi' },
      { date: '2025-10-02', name: 'Navratri Begins' },
      { date: '2025-10-20', name: 'Dussehra' },
      { date: '2025-11-09', name: 'Diwali' }
    ];

    const renderCalendar = () => {
      const calendarHeader = document.querySelector('.bg-neutral-900 h2');
      const calendarBody = document.getElementById('calendar-body');

      if (!calendarHeader || !calendarBody) return;

      const firstDay = new Date(currentYear, currentMonth, 1);
      const lastDay = new Date(currentYear, currentMonth + 1, 0);
      const daysInMonth = lastDay.getDate();
      const startingDay = firstDay.getDay();

      calendarHeader.textContent = `${firstDay.toLocaleString('en-IN', { month: 'long' })} ${currentYear}`;

      let calendarHTML = '';
      let day = 1;

      for (let i = 0; i < 6; i++) {
        for (let j = 0; j < 7; j++) {
          if (i === 0 && j < startingDay) {
            calendarHTML += '<div class="text-neutral-600"></div>';
          } else if (day > daysInMonth) {
            calendarHTML += '<div class="text-neutral-600"></div>';
          } else {
            const currentDate = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
            const festival = festivals.find(f => f.date === currentDate);
            const isToday = new Date().toISOString().split('T')[0] === currentDate;
            const isFuture = new Date(currentDate) > new Date();

            calendarHTML += `
              <div class="relative p-2 rounded-full ${isToday ? 'bg-primary text-white' : 'hover:bg-neutral-700'} ${festival && isFuture ? 'bg-accent text-white' : ''}">
                ${day}
                ${festival && isFuture ? `<span class="absolute -top-2 -right-2 bg-accent text-white text-xs px-1 rounded-full hidden group-hover:block">${festival.name}</span>` : ''}
              </div>
            `;
            day++;
          }
        }
        if (day > daysInMonth) break;
      }

      calendarBody.innerHTML = calendarHTML;
    };

    const prevMonthBtn = document.getElementById('prev-month');
    const nextMonthBtn = document.getElementById('next-month');

    prevMonthBtn?.addEventListener('click', () => {
      currentMonth--;
      if (currentMonth < 0) {
        currentMonth = 11;
        currentYear--;
      }
      renderCalendar();
    });

    nextMonthBtn?.addEventListener('click', () => {
      currentMonth++;
      if (currentMonth > 11) {
        currentMonth = 0;
        currentYear++;
      }
      renderCalendar();
    });

    renderCalendar();
  }

  displayUpcomingFestivals() {
    const festivals = [
      { date: '2025-08-09', name: 'Raksha Bandhan' },
      { date: '2025-08-16', name: 'Janmashtami' },
      { date: '2025-09-05', name: 'Ganesh Chaturthi' },
      { date: '2025-10-02', name: 'Navratri Begins' },
      { date: '2025-10-20', name: 'Dussehra' },
      { date: '2025-11-09', name: 'Diwali' }
    ];

    const upcomingFestivalsContainer = document.getElementById('upcoming-festivals');
    if (!upcomingFestivalsContainer) return;

    const upcomingFestivals = festivals
      .filter(festival => new Date(festival.date) > new Date())
      .sort((a, b) => new Date(a.date) - new Date(b.date))
      .slice(0, 3);

    upcomingFestivalsContainer.innerHTML = upcomingFestivals.map(festival => `
      <div class="bg-neutral-50 rounded-sm p-4 shadow-sm hover:shadow-md transition-shadow">
        <div class="flex items-center space-x-3">
          <div class="w-10 h-10 rounded-full bg-accent/10 flex items-center justify-center">
            <i class="fas fa-star text-accent"></i>
          </div>
          <div>
            <h3 class="text-lg font-medium text-neutral-900">${festival.name}</h3>
            <p class="text-sm text-neutral-500">${new Date(festival.date).toLocaleDateString('en-IN', { month: 'long', day: 'numeric', year: 'numeric' })}</p>
          </div>
        </div>
      </div>
    `).join('');
  }

  static showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `fixed bottom-4 right-4 px-4 py-2 rounded-sm text-white ${type === 'success' ? 'bg-secondary' :
      type === 'error' ? 'bg-error-500' :
        'bg-primary'
      }`;
    toast.textContent = message;
    document.body.appendChild(toast);

    setTimeout(() => {
      toast.remove();
    }, 3000);
  }

  static async simulateLoading(element, callback) {
    const originalContent = element.innerHTML;
    element.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
    element.disabled = true;

    try {
      await callback();
    } finally {
      element.innerHTML = originalContent;
      element.disabled = false;
    }
  }
}

class DashboardManager {
  constructor() {
    this.stateManager = new StateManager();
    this.uiManager = new UIManager();
    this.setupEventListeners();
    this.checkAuthentication();
    this.loadDashboardData();
  }

  setupEventListeners() {
    // Mobile menu toggle
    const mobileMenuButton = document.getElementById('mobile-menu-button');
    const sidebar = document.getElementById('sidebar');
    mobileMenuButton?.addEventListener('click', () => {
      sidebar.classList.toggle('-translate-x-full');
    });

    // Window resize handler for sidebar
    window.addEventListener('resize', () => {
      if (window.innerWidth >= 768) {
        sidebar.classList.remove('-translate-x-full');
      } else {
        sidebar.classList.add('-translate-x-full');
      }
    });

    // Add event button
    document.getElementById('add-event-btn')?.addEventListener('click', () => {
      window.location.href = '/F&B1/events.php';
    });

    // Logout button
    document.getElementById('logout-btn')?.addEventListener('click', (e) => {
      e.preventDefault();
      this.handleLogout();
    });
  }

  async loadDashboardData() {
    try {
      const formData = new FormData();
      formData.append('action', 'get_dashboard_data');

      const response = await fetch('/F&B1/dashboard.php', {
        method: 'POST',
        body: formData
      });

      const result = await response.json();

      if (result.success) {
        this.updateDashboard(result.data);
      } else {
        UIManager.showToast(result.message || 'Failed to load dashboard data', 'error');
      }
    } catch (error) {
      console.error('Error loading dashboard data:', error);
      UIManager.showToast('Failed to load dashboard data', 'error');
    }
  }

  updateDashboard(data) {
    // Update statistics
    this.updateEventStats(data.stats.events);
    this.updateShoppingStats(data.stats.shopping);
    this.updateTaskStats(data.stats.tasks);
    this.updateTemplateStats(data.stats.templates);

    // Update upcoming events
    this.updateUpcomingEvents(data.upcomingEvents);
    this.updateUpcomingShoppingEvents(data.upcomingShoppingEvents);

    // Update tasks
    this.updatePendingTasks(data.pendingTasks);
  }

  updateEventStats(stats) {
    const totalEvents = document.querySelector('[data-stat="total-events"]');
    const upcomingEvents = document.querySelector('[data-stat="upcoming-events"]');
    
    if (totalEvents) {
      totalEvents.textContent = stats.total_events || 0;
    }
    if (upcomingEvents) {
      upcomingEvents.textContent = stats.upcoming_events || 0;
    }
  }

  updateShoppingStats(stats) {
    const totalEvents = document.querySelector('[data-stat="total-shopping-events"]');
    if (totalEvents) {
      totalEvents.textContent = stats.total_shopping_events || 0;
    }
  }

  updateTaskStats(stats) {
    const totalTasks = document.querySelector('[data-stat="total-tasks"]');
    const taskCompletion = document.querySelector('[data-stat="task-completion"]');
    
    if (totalTasks) {
      totalTasks.textContent = stats.total_tasks || 0;
    }
    if (taskCompletion) {
      const completionRate = stats.total_tasks ? Math.round((stats.completed_tasks / stats.total_tasks) * 100) : 0;
      taskCompletion.textContent = `${completionRate}% Complete`;
    }
  }

  updateTemplateStats(stats) {
    const totalTemplates = document.querySelector('[data-stat="total-templates"]');
    if (totalTemplates) {
      totalTemplates.textContent = stats.total_templates || 0;
    }
  }

  updateUpcomingEvents(events) {
    const container = document.querySelector('.upcoming-events');
    if (!container) return;

    container.innerHTML = events.length ? events.map(event => `
      <div class="bg-white p-4 rounded-sm border border-neutral-200 hover:shadow-md transition-shadow">
        <div class="flex justify-between items-start">
          <div>
            <h3 class="font-semibold text-neutral-900">${event.title}</h3>
            <p class="text-sm text-neutral-500">${event.category}</p>
          </div>
          <span class="px-2 py-1 text-xs rounded-full ${event.status === 'upcoming' ? 'bg-primary/10 text-primary' :
        event.status === 'ongoing' ? 'bg-secondary/10 text-secondary' :
          'bg-neutral-100 text-neutral-600'
      }">${event.status}</span>
        </div>
        <div class="mt-2 space-y-1">
          <div class="flex items-center text-sm text-neutral-600">
            <i class="fas fa-calendar-alt w-5"></i>
            <span>${new Date(event.date).toLocaleDateString('en-IN')}</span>
          </div>
          <div class="flex items-center text-sm text-neutral-600">
            <i class="fas fa-map-marker-alt w-5"></i>
            <span>${event.venue || 'No venue set'}</span>
          </div>
        </div>
      </div>
    `).join('') : '<p class="text-neutral-500">No upcoming events</p>';
  }

  updateUpcomingShoppingEvents(events) {
    const container = document.querySelector('.upcoming-shopping-events');
    if (!container) return;

    container.innerHTML = events.length ? events.map(event => `
      <div class="bg-white p-4 rounded-sm border border-neutral-200 hover:shadow-md transition-shadow">
        <div class="flex justify-between items-start">
          <div>
            <h3 class="font-semibold text-neutral-900">${event.title}</h3>
            <p class="text-sm text-neutral-500">${event.category}</p>
          </div>
          <span class="px-2 py-1 text-xs rounded-full ${event.status === 'upcoming' ? 'bg-primary/10 text-primary' :
        'bg-neutral-100 text-neutral-600'
      }">${event.status}</span>
        </div>
        <div class="mt-2 space-y-1">
          <div class="flex items-center text-sm text-neutral-600">
            <i class="fas fa-calendar-alt w-5"></i>
            <span>${new Date(event.date).toLocaleDateString('en-IN')}</span>
          </div>
          <div class="flex items-center text-sm text-neutral-600">
            <i class="fas fa-store w-5"></i>
            <span>${event.location || 'No location set'}</span>
          </div>
        </div>
      </div>
    `).join('') : '<p class="text-neutral-500">No upcoming shopping events</p>';
  }

  updatePendingTasks(tasks) {
    const container = document.querySelector('.recent-tasks');
    if (!container) return;

    container.innerHTML = tasks.length ? tasks.map(task => `
      <div class="bg-white p-4 rounded-sm border border-neutral-200 hover:shadow-md transition-shadow">
        <div class="flex items-start justify-between">
          <div class="flex-1">
            <h4 class="font-medium text-neutral-900">${task.title}</h4>
            ${task.event_title ? `<p class="text-sm text-neutral-500">For: ${task.event_title}</p>` : ''}
          </div>
          <span class="px-2 py-1 text-xs rounded-full ${task.priority === 'high' ? 'bg-error-100 text-error-600' :
        task.priority === 'medium' ? 'bg-accent/10 text-accent' :
          'bg-neutral-100 text-neutral-600'
      }">${task.priority}</span>
        </div>
        <div class="mt-2 flex items-center text-sm text-neutral-600">
          <i class="fas fa-clock w-5"></i>
          <span>Due: ${new Date(task.deadline).toLocaleDateString('en-IN')}</span>
        </div>
      </div>
    `).join('') : '<p class="text-neutral-500">No pending tasks</p>';
  }

  async handleLogout() {
    try {
      await fetch('/F&B1/auth/logout.php');
      window.location.href = '/F&B1/auth/login.php';
    } catch (error) {
      console.error('Error during logout:', error);
      UIManager.showToast('Failed to logout. Please try again.', 'error');
    }
  }

  checkAuthentication() {
    const authToken = localStorage.getItem('authToken') || sessionStorage.getItem('authToken');
    if (!authToken) {
      window.location.href = '/F&B1/auth/login.php';
      return false;
    }
    return true;
  }
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  window.dashboardManager = new DashboardManager();
});