gsap.registerPlugin(ScrollTrigger);

class AdminDashboardUIManager {
    constructor() {
        this.loadingOverlay = document.getElementById('loading-overlay');
        this.notification = document.getElementById('notification');
        this.notificationMessage = document.getElementById('notification-message');
        this.forms = document.querySelectorAll('form');
    }

    initialize() {
        this.setupLoadingOverlay();
        this.setupNotifications();
        this.initializeAnimations();
    }

    setupLoadingOverlay() {
        if (!this.loadingOverlay) return;

        this.forms.forEach(form => {
            form.addEventListener('submit', () => {
                this.loadingOverlay.classList.remove('hidden');
            });
        });
    }

    setupNotifications() {
        if (!this.notification || !this.notificationMessage) return;

        document.addEventListener('showNotification', (e) => {
            this.showNotification(e.detail.message, e.detail.type, e.detail.duration);
        });
    }

    showNotification(message, type = 'success', duration = 3000) {
        if (!this.notification || !this.notificationMessage) return;

        const icons = {
            success: 'fa-check-circle text-green-600',
            error: 'fa-exclamation-circle text-red-600',
            warning: 'fa-exclamation-triangle text-yellow-600',
            info: 'fa-info-circle text-blue-600'
        };

        this.notificationMessage.textContent = message;
        document.getElementById('notification-icon').className = `fas ${icons[type] || icons.info}`;
        this.notification.classList.remove('hidden');

        setTimeout(() => {
            this.notification.classList.add('hidden');
        }, duration);
    }

    initializeAnimations() {
        // Header animation
        gsap.from('h1', {
            opacity: 0,
            y: 30,
            duration: 1,
            scrollTrigger: {
                trigger: 'h1',
                start: 'top center+=100'
            }
        });

        // Section animations
        gsap.from('.grid', {
            opacity: 0,
            y: 30,
            duration: 1,
            stagger: 0.2,
            scrollTrigger: {
                trigger: '.grid',
                start: 'top center+=100'
            }
        });

        // Table animation
        gsap.from('table', {
            opacity: 0,
            y: 30,
            duration: 1,
            scrollTrigger: {
                trigger: 'table',
                start: 'top center+=100'
            }
        });
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const ui = new AdminDashboardUIManager();
    ui.initialize();

    // Show welcome notification
    setTimeout(() => {
        const event = new CustomEvent('showNotification', {
            detail: {
                message: 'Welcome to the Admin Dashboard! 📊',
                type: 'success',
                duration: 4000
            }
        });
        document.dispatchEvent(event);
    }, 1000);
});