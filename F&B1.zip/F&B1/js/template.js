// Initialize GSAP ScrollTrigger
gsap.registerPlugin(ScrollTrigger);

// Predefined Templates
const predefinedTemplates = [
  // Indian Festivals
  {
    id: "diwali-celebration",
    name: "Diwali Celebration",
    category: "festival",
    type: "Indian Festival",
    description: "Plan a vibrant Diwali celebration with fireworks, diyas, and sweets.",
    budget: 150000,
    tasks: [
      { title: "Book Pandit for Lakshmi Puja", category: "vendor", priority: "high", due_date: "30 days before", assigned_to: "user1", notes: "Ensure availability for evening puja." },
      { title: "Purchase Diyas and Candles", category: "logistics", priority: "medium", due_date: "7 days before", assigned_to: "", notes: "Buy eco-friendly diyas." },
      { title: "Arrange Fireworks Display", category: "logistics", priority: "high", due_date: "10 days before", assigned_to: "user2", notes: "Check safety regulations." },
      { title: "Plan Festive Menu", category: "planning", priority: "medium", due_date: "14 days before", assigned_to: "user3", notes: "Include traditional sweets like ladoos and barfis." },
      { title: "Invite Family and Friends", category: "guest", priority: "high", due_date: "20 days before", assigned_to: "", notes: "Send e-invites or cards." }
    ],
    isCustom: false
  },
  {
    id: "holi-festival",
    name: "Holi Festival",
    category: "festival",
    type: "Indian Festival",
    description: "Organize a colorful Holi party with music, colors, and festive foods.",
    budget: 100000,
    tasks: [
      { title: "Buy Organic Colors", category: "logistics", priority: "high", due_date: "7 days before", assigned_to: "user2", notes: "Ensure skin-friendly colors." },
      { title: "Arrange DJ for Music", category: "vendor", priority: "medium", due_date: "10 days before", assigned_to: "", notes: "Include Bollywood Holi songs." },
      { title: "Plan Refreshment Menu", category: "planning", priority: "medium", due_date: "14 days before", assigned_to: "user3", notes: "Include thandai and gujiyas." }
    ],
    isCustom: false
  },
  {
    id: "navratri-celebration",
    name: "Navratri Celebration",
    category: "festival",
    type: "Indian Festival",
    description: "Host a 9-day Navratri event with garba, dandiya, and puja.",
    budget: 200000,
    tasks: [
      { title: "Book Venue for Garba Nights", category: "vendor", priority: "high", due_date: "30 days before", assigned_to: "user1", notes: "Ensure space for 100+ people." },
      { title: "Hire Dandiya Band", category: "vendor", priority: "medium", due_date: "20 days before", assigned_to: "", notes: "Traditional Gujarati band preferred." },
      { title: "Arrange Puja Items for Aarti", category: "logistics", priority: "high", due_date: "7 days before", assigned_to: "user3", notes: "Include garlands and prasad." }
    ],
    isCustom: false
  },
  // Indian Weddings
  {
    id: "hindu-wedding",
    name: "Hindu Wedding",
    category: "wedding",
    type: "Indian Wedding",
    description: "A traditional Hindu wedding with all major ceremonies and rituals.",
    budget: 500000,
    tasks: [
      { title: "Book Wedding Venue", category: "vendor", priority: "high", due_date: "60 days before", assigned_to: "user1", notes: "Outdoor venue with mandap setup." },
      { title: "Hire Pandit for Ceremonies", category: "vendor", priority: "high", due_date: "45 days before", assigned_to: "user2", notes: "For Haldi, Mehendi, and main ceremony." },
      { title: "Plan Catering Menu", category: "vendor", priority: "medium", due_date: "30 days before", assigned_to: "user3", notes: "Include North Indian cuisine." },
      { title: "Send Wedding Invitations", category: "guest", priority: "high", due_date: "45 days before", assigned_to: "", notes: "Design traditional cards." },
      { title: "Book Photographer", category: "vendor", priority: "medium", due_date: "30 days before", assigned_to: "", notes: "Include candid photography." }
    ],
    isCustom: false
  },
  {
    id: "Jain-wedding",
    name: "Jain Wedding",
    category: "wedding",
    type: "Indian Wedding",
    description: "Plan a Jain wedding with traditional ceremonies.",
    budget: 450000,
    tasks: [
      { title: "Book Venue", category: "vendor", priority: "high", due_date: "60 days before", assigned_to: "user1", notes: "Ensure separate seating for men and women." },
      { title: "Hire pandit for shadi", category: "vendor", priority: "high", due_date: "45 days before", assigned_to: "user2", notes: "Confirm availability for date." },
      { title: "Plan Menu", category: "planning", priority: "medium", due_date: "30 days before", assigned_to: "user3", notes: "Include snacks and sweets." }
    ],
    isCustom: false
  },
  // Birthdays & Parties
  {
    id: "birthday-party",
    name: "Children's Birthday Party",
    category: "birthday-party",
    type: "Birthday & Party",
    description: "Organize a fun-filled children's birthday party with games and decorations.",
    budget: 50000,
    tasks: [
      { title: "Book Party Venue", category: "vendor", priority: "high", due_date: "20 days before", assigned_to: "user1", notes: "Indoor space with play area." },
      { title: "Order Birthday Cake", category: "vendor", priority: "medium", due_date: "7 days before", assigned_to: "user2", notes: "Theme-based cake (e.g., cartoon character)." },
      { title: "Arrange Decorations", category: "logistics", priority: "medium", due_date: "5 days before", assigned_to: "user3", notes: "Balloons, streamers, and banners." },
      { title: "Plan Party Games", category: "planning", priority: "medium", due_date: "10 days before", assigned_to: "", notes: "Include musical chairs and treasure hunt." },
      { title: "Send Invitations", category: "guest", priority: "high", due_date: "15 days before", assigned_to: "", notes: "Invite classmates and friends." }
    ],
    isCustom: false
  },
  {
    id: "anniversary-party",
    name: "Anniversary Celebration",
    category: "birthday-party",
    type: "Birthday & Party",
    description: "Plan a memorable anniversary party with dinner and music.",
    budget: 80000,
    tasks: [
      { title: "Book Restaurant Venue", category: "vendor", priority: "high", due_date: "20 days before", assigned_to: "user1", notes: "Private dining area preferred." },
      { title: "Hire Live Music Band", category: "vendor", priority: "medium", due_date: "15 days before", assigned_to: "user2", notes: "Bollywood classics." },
      { title: "Plan Dinner Menu", category: "planning", priority: "medium", due_date: "10 days before", assigned_to: "user3", notes: "Include couple's favorite dishes." },
      { title: "Invite Close Family", category: "guest", priority: "high", due_date: "15 days before", assigned_to: "", notes: "Send formal invites." }
    ],
    isCustom: false
  },
  // Trips
  {
    id: "hill-station-retreat",
    name: "Hill Station Retreat",
    category: "trip",
    type: "Trip",
    description: "Plan a relaxing trip to a hill station with scenic views.",
    budget: 50000,
    tasks: [
      { title: "Book Hill Station Hotel", category: "logistics", priority: "high", due_date: "30 days before", assigned_to: "user1", notes: "Room with valley view." },
      { title: "Plan Sightseeing Itinerary", category: "planning", priority: "medium", due_date: "14 days before", assigned_to: "user2", notes: "Include sunrise points." },
      { title: "Arrange Car Rental", category: "logistics", priority: "high", due_date: "20 days before", assigned_to: "user3", notes: "SUV for mountain roads." }
    ],
    isCustom: false
  },
  {
    id: "beach-vacation",
    name: "Beach Vacation",
    category: "trip",
    type: "Trip",
    description: "Organize a fun beach vacation with water sports and relaxation.",
    budget: 60000,
    tasks: [
      { title: "Book Beach Resort", category: "logistics", priority: "high", due_date: "30 days before", assigned_to: "user1", notes: "Ocean-facing rooms." },
      { title: "Plan Water Sports Activities", category: "planning", priority: "medium", due_date: "14 days before", assigned_to: "user2", notes: "Jet skiing and snorkeling." },
      { title: "Arrange Flight Tickets", category: "logistics", priority: "high", due_date: "20 days before", assigned_to: "user3", notes: "Book return flights." }
    ],
    isCustom: false
  }
];

class TemplateManager {
  constructor() {
    this.storageKey = 'custom_templates';
    this.eventStorageKey = 'events';
    this.templates = [...predefinedTemplates];
    this.currentTemplate = null;
    this.customTemplateForm = document.getElementById('custom-template-form');
    this.eventForm = document.getElementById('event-form');
    this.templateGrid = document.getElementById('template-grid');
    this.sidebarUpcomingEvents = document.getElementById('sidebar-upcoming-events');
    this.customTemplateModal = document.getElementById('custom-template-modal');
    this.eventModal = document.getElementById('event-modal');
    this.previewModal = document.getElementById('preview-modal');
    this.loadCustomTemplates();
    this.setupEventListeners();
    this.displayUpcomingEvents();
  }

  loadCustomTemplates() {
    try {
      const customTemplates = JSON.parse(localStorage.getItem(this.storageKey) || '[]');
      this.templates = [...predefinedTemplates, ...customTemplates];
      this.renderTemplates();
    } catch (error) {
      console.error('Error loading custom templates:', error);
      this.templates = [...predefinedTemplates];
    }
  }

  saveCustomTemplates() {
    const customTemplates = this.templates.filter(t => t.isCustom);
    localStorage.setItem(this.storageKey, JSON.stringify(customTemplates));
    this.renderTemplates();
  }

  setupEventListeners() {
    // Mobile menu toggle
    const mobileMenuButton = document.getElementById('mobile-menu-button');
    const sidebar = document.getElementById('sidebar');
    mobileMenuButton?.addEventListener('click', () => {
      sidebar.classList.toggle('-translate-x-full');
    });

    // Window resize handler for sidebar
    window.addEventListener('resize', () => {
      if (window.innerWidth >= 768) {
        sidebar.classList.remove('-translate-x-full');
      } else {
        sidebar.classList.add('-translate-x-full');
      }
    });

    // Custom Template Modal controls
    document.getElementById('create-custom-template-btn')?.addEventListener('click', () => this.showCustomModal());
    document.getElementById('close-custom-modal')?.addEventListener('click', () => this.hideCustomModal());
    document.getElementById('cancel-template')?.addEventListener('click', () => this.hideCustomModal());
    this.customTemplateModal?.addEventListener('click', (e) => {
      if (e.target === this.customTemplateModal) {
        this.hideCustomModal();
      }
    });

    // Event Modal controls
    document.getElementById('close-event-modal')?.addEventListener('click', () => this.hideEventModal());
    document.getElementById('cancel-event')?.addEventListener('click', () => this.hideEventModal());
    this.eventModal?.addEventListener('click', (e) => {
      if (e.target === this.eventModal) {
        this.hideEventModal();
      }
    });

    // Preview Modal controls
    document.getElementById('close-preview-modal')?.addEventListener('click', () => this.hidePreviewModal());
    this.previewModal?.addEventListener('click', (e) => {
      if (e.target === this.previewModal) {
        this.hidePreviewModal();
      }
    });

    // Form submissions
    this.customTemplateForm?.addEventListener('submit', (e) => {
      e.preventDefault();
      this.saveTemplate();
    });

    this.eventForm?.addEventListener('submit', (e) => {
      e.preventDefault();
      this.createEvent();
    });

    // Add task buttons
    document.getElementById('add-template-task-btn')?.addEventListener('click', () => this.addTask('template-task-list'));
    document.getElementById('add-event-task-btn')?.addEventListener('click', () => this.addTask('event-task-list'));

    // Initialize filters
    this.templateFilter = new TemplateFilter(this);
  }

  showCustomModal(templateId = null) {
    this.currentTemplate = templateId ? this.templates.find(t => t.id === templateId) : null;
    document.getElementById('custom-modal-title').textContent = this.currentTemplate ? 'Edit Template' : 'Create Custom Template';

    if (this.currentTemplate) {
      document.getElementById('template-id').value = this.currentTemplate.id;
      document.getElementById('template-title').value = this.currentTemplate.name;
      document.getElementById('template-category').value = this.currentTemplate.category;
      document.getElementById('template-budget').value = this.currentTemplate.budget;
      document.getElementById('template-description').value = this.currentTemplate.description || '';
      const taskList = document.getElementById('template-task-list');
      taskList.innerHTML = '';
      this.currentTemplate.tasks.forEach(task => this.addTask('template-task-list', task));
    } else {
      this.customTemplateForm.reset();
      document.getElementById('template-id').value = '';
      document.getElementById('template-task-list').innerHTML = '';
    }

    this.customTemplateModal.classList.remove('hidden');
    gsap.from(this.customTemplateModal.children[0], {
      opacity: 0,
      y: -50,
      duration: 0.3,
      ease: 'power2.out'
    });
  }

  hideCustomModal() {
    gsap.to(this.customTemplateModal.children[0], {
      opacity: 0,
      y: -50,
      duration: 0.3,
      ease: 'power2.in',
      onComplete: () => {
        this.customTemplateModal.classList.add('hidden');
        this.customTemplateForm.reset();
        document.getElementById('template-task-list').innerHTML = '';
        this.currentTemplate = null;
      }
    });
  }

  showEventModal(templateId) {
    const template = this.templates.find(t => t.id === templateId);
    if (!template) return;

    this.currentTemplate = template;
    document.getElementById('event-template-id').value = template.id;
    document.getElementById('event-title').value = template.name;
    document.getElementById('event-category').value = template.category;
    document.getElementById('event-budget').value = template.budget;
    document.getElementById('event-description').value = template.description || '';
    const taskList = document.getElementById('event-task-list');
    taskList.innerHTML = '';
    template.tasks.forEach(task => this.addTask('event-task-list', task));

    this.eventModal.classList.remove('hidden');
    gsap.from(this.eventModal.children[0], {
      opacity: 0,
      y: -50,
      duration: 0.3,
      ease: 'power2.out'
    });
  }

  hideEventModal() {
    gsap.to(this.eventModal.children[0], {
      opacity: 0,
      y: -50,
      duration: 0.3,
      ease: 'power2.in',
      onComplete: () => {
        this.eventModal.classList.add('hidden');
        this.eventForm.reset();
        document.getElementById('event-task-list').innerHTML = '';
        this.currentTemplate = null;
      }
    });
  }

  showPreviewModal(templateId) {
    const template = this.templates.find(t => t.id === templateId);
    if (!template) return;

    const previewContent = document.getElementById('preview-content');
    previewContent.innerHTML = `
      <div class="space-y-4">
        <div>
          <h3 class="text-lg font-semibold text-neutral-900">${template.name}</h3>
          <p class="text-sm text-neutral-500">${template.type}</p>
        </div>
        <p class="text-neutral-600">${template.description}</p>
        <div class="flex items-center justify-between text-sm">
          <div class="flex items-center text-neutral-600">
            <i class="fas fa-tasks w-5 text-primary"></i>
            <span class="ml-2">${template.tasks.length} Tasks</span>
          </div>
          <div class="flex items-center text-neutral-600">
            <i class="fas fa-wallet w-5 text-accent"></i>
            <span class="ml-2">₹${template.budget.toLocaleString()}</span>
          </div>
        </div>
        <div class="border-t border-neutral-200 pt-4">
          <h4 class="text-md font-semibold text-neutral-900 mb-2">Tasks</h4>
          <div class="space-y-2">
            ${template.tasks.map(task => `
              <div class="bg-neutral-50 p-3 rounded-sm">
                <p class="font-medium text-neutral-800">${task.title}</p>
                <div class="flex items-center justify-between mt-1">
                  <span class="text-sm text-neutral-500">${task.category.charAt(0).toUpperCase() + task.category.slice(1)}</span>
                  <span class="px-2 py-1 text-xs rounded-full ${task.priority === 'high' ? 'bg-error-100 text-error-600' :
        task.priority === 'medium' ? 'bg-accent/10 text-accent' :
          'bg-secondary/10 text-secondary'
      }">${task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}</span>
                </div>
              </div>
            `).join('')}
          </div>
        </div>
      </div>
    `;

    document.getElementById('use-template-from-preview').onclick = () => {
      this.hidePreviewModal();
      this.showEventModal(templateId);
    };

    this.previewModal.classList.remove('hidden');
    gsap.from(this.previewModal.children[0], {
      opacity: 0,
      y: -50,
      duration: 0.3,
      ease: 'power2.out'
    });
  }

  hidePreviewModal() {
    gsap.to(this.previewModal.children[0], {
      opacity: 0,
      y: -50,
      duration: 0.3,
      ease: 'power2.in',
      onComplete: () => {
        this.previewModal.classList.add('hidden');
      }
    });
  }

  addTask(listId, task = null) {
    const taskList = document.getElementById(listId);
    const taskTemplate = document.getElementById('task-template').content.cloneNode(true);
    const taskItem = taskTemplate.querySelector('.task-item');

    if (task) {
      taskItem.querySelector('.task-title').value = task.title;
      taskItem.querySelector('.task-category').value = task.category;
      taskItem.querySelector('.task-priority').value = task.priority;
      taskItem.querySelector('.task-due-date').value = task.due_date;
      taskItem.querySelector('.task-assigned').value = task.assigned_to || '';
      taskItem.querySelector('.task-notes').value = task.notes || '';
    } else {
      taskItem.querySelector('.task-due-date').value = '30 days before';
    }

    // Toggle Details
    taskItem.querySelector('.toggle-details').addEventListener('click', () => {
      const taskDetails = taskItem.querySelector('.task-details');
      taskDetails.classList.toggle('hidden');
      const icon = taskItem.querySelector('.toggle-details i');
      icon.classList.toggle('fa-chevron-down');
      icon.classList.toggle('fa-chevron-up');
    });

    // Delete Task
    taskItem.querySelector('.delete-task').addEventListener('click', () => {
      taskItem.remove();
    });

    taskList.appendChild(taskTemplate);
  }

  saveTemplate() {
    const templateId = document.getElementById('template-id').value;
    const templateData = {
      id: templateId || `custom-${Date.now()}`,
      name: document.getElementById('template-title').value,
      category: document.getElementById('template-category').value,
      type: document.getElementById('template-category').options[document.getElementById('template-category').selectedIndex].text,
      description: document.getElementById('template-description').value,
      budget: parseInt(document.getElementById('template-budget').value),
      tasks: Array.from(document.getElementById('template-task-list').querySelectorAll('.task-item')).map(task => ({
        title: task.querySelector('.task-title').value,
        category: task.querySelector('.task-category').value,
        priority: task.querySelector('.task-priority').value,
        due_date: task.querySelector('.task-due-date').value,
        assigned_to: task.querySelector('.task-assigned').value,
        notes: task.querySelector('.task-notes').value
      })),
      isCustom: true
    };

    // Validate required fields
    if (!templateData.name || !templateData.category || !templateData.budget) {
      this.showNotification('Please fill all required fields.', 'error');
      return;
    }

    try {
      if (templateId) {
        const templateIndex = this.templates.findIndex(t => t.id === templateId);
        this.templates[templateIndex] = templateData;
      } else {
        this.templates.push(templateData);
      }

      this.saveCustomTemplates();
      this.showNotification(templateId ? 'Template updated successfully!' : 'Template created successfully!', 'success');
      this.hideCustomModal();
    } catch (error) {
      console.error('Error saving template:', error);
      this.showNotification('Failed to save template. Please try again.', 'error');
    }
  }

  createEvent() {
    const eventData = {
      id: Date.now(),
      title: document.getElementById('event-title').value,
      category: document.getElementById('event-category').value,
      description: document.getElementById('event-description').value,
      start_date: document.getElementById('event-start-date').value,
      end_date: document.getElementById('event-end-date').value || document.getElementById('event-start-date').value,
      venue: document.getElementById('event-venue').value,
      budget: parseInt(document.getElementById('event-budget').value),
      tasks: Array.from(document.getElementById('event-task-list').querySelectorAll('.task-item')).map(task => ({
        title: task.querySelector('.task-title').value,
        category: task.querySelector('.task-category').value,
        priority: task.querySelector('.task-priority').value,
        due_date: task.querySelector('.task-due-date').value,
        assigned_to: task.querySelector('.task-assigned').value,
        notes: task.querySelector('.task-notes').value,
        completed: false
      })),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    // Validate required fields
    if (!eventData.title || !eventData.category || !eventData.start_date || !eventData.venue || !eventData.budget) {
      this.showNotification('Please fill all required fields.', 'error');
      return;
    }

    try {
      const events = JSON.parse(localStorage.getItem(this.eventStorageKey) || '[]');
      events.push(eventData);
      localStorage.setItem(this.eventStorageKey, JSON.stringify(events));
      this.showNotification('Event created successfully!', 'success');
      this.hideEventModal();
      this.displayUpcomingEvents();
    } catch (error) {
      console.error('Error creating event:', error);
      this.showNotification('Failed to create event. Please try again.', 'error');
    }
  }

  duplicateTemplate(templateId) {
    const template = this.templates.find(t => t.id === templateId);
    if (!template) return;

    const newTemplate = {
      ...template,
      id: `custom-${Date.now()}`,
      name: `${template.name} (Copy)`,
      isCustom: true
    };

    this.templates.push(newTemplate);
    this.saveCustomTemplates();
    this.showNotification('Template duplicated successfully!', 'success');
  }

  deleteTemplate(templateId) {
    if (!confirm('Are you sure you want to delete this template?')) return;

    this.templates = this.templates.filter(t => t.id !== templateId);
    this.saveCustomTemplates();
    this.showNotification('Template deleted successfully!', 'success');
  }

  displayUpcomingEvents() {
    const events = JSON.parse(localStorage.getItem(this.eventStorageKey) || '[]');
    const now = new Date();
    const upcomingEvents = events.filter(event => {
      const eventDate = new Date(event.start_date);
      const diffDays = Math.ceil((eventDate - now) / (1000 * 60 * 60 * 24));
      return diffDays >= 0 && diffDays <= 30;
    });

    this.sidebarUpcomingEvents.innerHTML = upcomingEvents.length > 0 ? upcomingEvents.map(event => {
      const eventDate = new Date(event.start_date);
      const diffDays = Math.ceil((eventDate - now) / (1000 * 60 * 60 * 24));
      return `
        <div class="bg-neutral-50 p-3 rounded-sm">
          <p class="font-medium text-neutral-800">${event.title}</p>
          <div class="flex items-center justify-between mt-1">
            <span class="text-sm text-neutral-500"><i class="fas fa-calendar-alt mr-1"></i>${eventDate.toLocaleDateString('en-IN')}</span>
            <span class="text-xs px-2 py-1 bg-primary/10 text-primary rounded-full">${diffDays} day${diffDays !== 1 ? 's' : ''} left</span>
          </div>
        </div>
      `;
    }).join('') : '<p class="text-neutral-500">No upcoming events.</p>';
  }

  renderTemplates(templates) {
    if (!templates) templates = this.templates;

    this.templateGrid.innerHTML = '';
    let currentCategory = '';

    templates.forEach(template => {
      if (currentCategory !== template.category) {
        currentCategory = template.category;
        const categoryHeader = document.createElement('div');
        categoryHeader.className = 'col-span-full mt-6 mb-4 first:mt-0';
        categoryHeader.innerHTML = `
          <h2 class="text-xl font-semibold text-neutral-900 flex items-center">
            <i class="fas ${this.getCategoryIcon(template.category)} mr-2 text-primary"></i>
            ${this.getCategoryTitle(template.category)}
          </h2>
        `;
        this.templateGrid.appendChild(categoryHeader);
      }

      const cardTemplate = document.getElementById('template-card-template').content.cloneNode(true);
      const card = cardTemplate.querySelector('.template-card');

      card.querySelector('.template-name').textContent = template.name;
      card.querySelector('.template-category').textContent = `Category: ${template.type}`;
      card.querySelector('.template-type').textContent = template.isCustom ? 'Custom' : 'Predefined';
      card.querySelector('.template-description').textContent = template.description;
      card.querySelector('.template-task-count').textContent = `${template.tasks.length} Tasks`;
      card.querySelector('.template-budget').textContent = `₹${template.budget.toLocaleString()}`;
      card.classList.add(this.getCategoryColorClass(template.category));

      if (template.isCustom) {
        card.querySelector('.delete-template-btn').classList.remove('hidden');
      }

      card.querySelector('.use-template-btn').addEventListener('click', () => this.showEventModal(template.id));
      card.querySelector('.preview-template-btn').addEventListener('click', () => this.showPreviewModal(template.id));
      card.querySelector('.edit-template-btn').addEventListener('click', () => this.showCustomModal(template.id));
      card.querySelector('.duplicate-template-btn').addEventListener('click', () => this.duplicateTemplate(template.id));
      card.querySelector('.delete-template-btn')?.addEventListener('click', () => this.deleteTemplate(template.id));

      this.templateGrid.appendChild(cardTemplate);
    });

    if (templates.length === 0) {
      this.templateGrid.innerHTML = `
        <div class="col-span-full text-center py-8">
          <div class="text-neutral-500">
            <i class="fas fa-search mb-2 text-2xl"></i>
            <p>No templates found matching your criteria.</p>
          </div>
        </div>
      `;
    }

    gsap.from('#template-grid > div', {
      y: 50,
      opacity: 0,
      duration: 0.5,
      stagger: 0.1,
      ease: 'power2.out'
    });
  }

  getCategoryIcon(category) {
    const icons = {
      'festival': 'fa-star',
      'wedding': 'fa-rings-wedding',
      'birthday-party': 'fa-birthday-cake',
      'trip': 'fa-plane-departure'
    };
    return icons[category] || 'fa-file-alt';
  }

  getCategoryTitle(category) {
    const titles = {
      'festival': 'Indian Festivals',
      'wedding': 'Indian Weddings',
      'birthday-party': 'Birthdays & Parties',
      'trip': 'Travel & Trips'
    };
    return titles[category] || category.charAt(0).toUpperCase() + category.slice(1);
  }

  getCategoryColorClass(category) {
    const colors = {
      'festival': 'hover:border-primary',
      'wedding': 'hover:border-accent',
      'birthday-party': 'hover:border-secondary',
      'trip': 'hover:border-secondary'
    };
    return colors[category] || 'hover:border-primary';
  }

  showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `fixed top-4 right-4 px-6 py-3 rounded-lg ${type === 'success' ? 'bg-secondary/20 text-secondary' : 'bg-error-500/20 text-error-500'}`;
    notification.textContent = message;

    document.body.appendChild(notification);

    gsap.from(notification, {
      x: 100,
      opacity: 0,
      duration: 0.3,
      ease: 'power2.out'
    });

    setTimeout(() => {
      gsap.to(notification, {
        x: 100,
        opacity: 0,
        duration: 0.3,
        ease: 'power2.in',
        onComplete: () => notification.remove()
      });
    }, 3000);
  }
}

class TemplateFilter {
  constructor(templateManager) {
    this.templateManager = templateManager;
    this.filters = {
      search: '',
      category: '',
      sort: 'name-asc'
    };
    this.setupFilterListeners();
  }

  setupFilterListeners() {
    document.getElementById('search-templates')?.addEventListener('input', (e) => {
      this.filters.search = e.target.value.toLowerCase();
      this.applyFilters();
    });

    document.getElementById('category-filter')?.addEventListener('change', (e) => {
      this.filters.category = e.target.value;
      this.applyFilters();
    });

    document.getElementById('sort-filter')?.addEventListener('change', (e) => {
      this.filters.sort = e.target.value;
      this.applyFilters();
    });
  }

  applyFilters() {
    let filteredTemplates = this.templateManager.templates.filter(template => {
      if (this.filters.search &&
        !template.name.toLowerCase().includes(this.filters.search) &&
        !template.description.toLowerCase().includes(this.filters.search)) {
        return false;
      }

      if (this.filters.category && template.category !== this.filters.category) {
        return false;
      }

      return true;
    });

    filteredTemplates = this.sortTemplates(filteredTemplates);
    this.templateManager.renderTemplates(filteredTemplates);
  }

  sortTemplates(templates) {
    return [...templates].sort((a, b) => {
      switch (this.filters.sort) {
        case 'name-asc':
          return a.name.localeCompare(b.name);
        case 'name-desc':
          return b.name.localeCompare(a.name);
        case 'tasks-asc':
          return a.tasks.length - b.tasks.length;
        case 'tasks-desc':
          return b.tasks.length - a.tasks.length;
        case 'budget-asc':
          return a.budget - b.budget;
        case 'budget-desc':
          return b.budget - a.budget;
        default:
          return 0;
      }
    }).sort((a, b) => {
      const categoryOrder = { 'festival': 1, 'wedding': 2, 'birthday-party': 3, 'trip': 4 };
      return categoryOrder[a.category] - categoryOrder[b.category];
    });
  }
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  window.templateManager = new TemplateManager();

  // GSAP Animations
  gsap.from('header', {
    opacity: 0,
    y: -20,
    duration: 0.6,
    ease: "power2.out"
  });

  gsap.from('.mb-6', {
    opacity: 0,
    y: 30,
    duration: 0.6,
    stagger: 0.1,
    ease: "power2.out",
    scrollTrigger: {
      trigger: '.mb-6',
      start: 'top 80%'
    }
  });

  gsap.from('#create-custom-template-btn', {
    opacity: 0,
    scale: 0.8,
    duration: 0.6,
    ease: "back.out(1.7)"
  });
});